# deep-translate (portable export)

A Claude Code skill that rewrites a localized page's non-English content into
100% native, journalist-grade language across three escalating passes.

## Install into another project

Copy the `deep-translate/` folder into the target project's skills directory:

```
<target-project>/.claude/skills/deep-translate/
  SKILL.md
  HUMANIZER.md
```

(Or into `~/.claude/skills/deep-translate/` to make it available globally.)

Then invoke it with `/deep-translate` and supply the target **language** and
the **page path** when asked.

## What's in here

- `deep-translate/SKILL.md` — the skill, generalized to be project-neutral
  (no BeyondBridge-specific house rules or path assumptions).
- `deep-translate/HUMANIZER.md` — the AI-writing-tell catalogue that backs
  Step 1. The skill references it from its own folder, so keep them together.

## Adapting

The skill honors any host-project house rules (banned words/characters,
brand-name handling, subject/framing constraints) if the project defines them
in a `CLAUDE.md` or style guide. Add those at the destination if you want them
enforced; the skill picks them up without edits.

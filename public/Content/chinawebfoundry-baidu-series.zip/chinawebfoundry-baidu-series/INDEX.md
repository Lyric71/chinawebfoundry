# Baidu series, 16 finished articles

All sixteen ran the full 18-pass ContentQuality loop. Versions v1 to v18 and the review notes for each iteration are kept per article. Every file: US journalist prose, zero em dashes, no summary section, blockquote citations with attribution, Chinese terms as English term (characters, pinyin) on first use, no planted typos.

| File | Title | Title chars | Meta chars | Excerpt words | Words |
|---|---|---|---|---|---|
| baidu-search-resource-platform.md | What Is the Baidu Search Resource Platform? | 43 | 143 | 25 | 1410 |
| baidu-account-ownership.md | Who Owns Your Baidu Account? | 28 | 152 | 25 | 1306 |
| baidu-account-foreign-company.md | Getting a Baidu Account as a Foreign Company | 44 | 142 | 25 | 1079 |
| baidu-site-verification.md | Verify Your Site on Baidu: File or HTML Tag | 43 | 146 | 25 | 982 |
| baidu-verification-scope.md | Baidu Verification: www, HTTPS and Subdomains | 45 | 145 | 25 | 1290 |
| baidu-verification-failed.md | Baidu Site Verification Failed: The Usual Causes | 48 | 146 | 25 | 1552 |
| baiduspider-firewall.md | Baiduspider Blocked by Cloudflare and WAF Rules | 47 | 141 | 25 | 1316 |
| submitting-urls-to-baidu.md | Submit a Website to Baidu: Push, Sitemap, Manual | 48 | 133 | 25 | 1302 |
| baidu-fast-inclusion-gone.md | Baidu Fast Inclusion Is Gone. What Replaced It | 46 | 137 | 25 | 1299 |
| baidu-index-traffic-data.md | Reading Baidu's Index Volume and Traffic Data | 45 | 139 | 25 | 1312 |
| baidu-merchant-center.md | Baidu Merchant Center: What BMC Actually Does | 45 | 142 | 25 | 1263 |
| baidu-product-feed.md | How to Build a Baidu Product Feed | 33 | 138 | 25 | 1261 |
| baidu-product-data-destinations.md | Baidu DPA: Where Product Feed Data Actually Goes | 48 | 141 | 25 | 1346 |
| baidu-ads-account-foreign.md | A Baidu Ads Account Without a Chinese Entity | 44 | 140 | 25 | 1268 |
| baidu-structured-data.md | Baidu Structured Data: What Still Works | 39 | 144 | 25 | 1313 |
| baidu-aicaigou-b2b.md | Baidu Aicaigou: B2B Search in China | 35 | 146 | 25 | 1299 |

## Publication order

Series A first: A1 through A5 as a block, then A6, then A7 through A10. Series B after, led by B3.

## Fact base

Every claim traces to a shared approved fact base built from Chinese-language sources. Where sources conflict or a figure comes from practitioner blogs rather than a Baidu announcement, the copy hedges it in the sentence itself. Two items to re-check on publication day: the fast crawl VIP click threshold, and Aicaigou membership pricing.

## Verification log, August 19, 2026

Two hedged claims were re-checked against live Chinese sources before delivery.

**Fast crawl VIP thresholds (article 08).** Baidu's own announcement, quoted by 泪雪博客, confirms only that VIP partners of the Search Resource Platform are granted the privilege automatically, and that fast crawl replaced fast inclusion on April 26, 2024. The specific entry criteria were published alongside the November 24, 2023 VIP club relaunch as an image rather than as text, so every figure in circulation, including the 10,000 average daily clicks floor, is secondhand. The article now says this explicitly instead of attributing the numbers loosely to blogs.

**Aicaigou pricing (article 16).** The RMB 6,980 annual figure is better sourced than first assessed: it appears on a Baidu marketing channel page dated June 2021, alongside the confirmation that entry runs through a service provider and that bidding is charged per click. A June 2026 service provider source puts basic entry at roughly RMB 6,000 to 8,000 a year. The RMB 19,800 local merchant tier could not be corroborated on re-check and has been removed from the article.

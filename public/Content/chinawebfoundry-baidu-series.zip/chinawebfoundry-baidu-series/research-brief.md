---
title: "Baidu Verification and BMC: Research Brief"
slug: baidu-ziyuan-verification-bmc-research
description: "Research brief on Baidu Search Resource Platform site verification and Baidu Merchant Center distribution, plus proposed China Web Guide articles."
excerpt: "What site verification and Baidu Merchant Center actually do, and eight guide articles worth writing."
template: internal-brief
---

<!-- SECTION 1: WHAT THESE TWO THINGS ACTUALLY ARE -->

# Part 1. Site verification on the Baidu Search Resource Platform

## The short version

Site verification on the Baidu Search Resource Platform (百度搜索资源平台) is the step that turns a domain into a claimed property you can see data for and submit URLs to. The mechanics take ten minutes. The account behind the verification is the part that stops foreign companies cold, and that has been true since September 2023, not since the old guides were written.

## The mechanics, current as of August 2026

Two methods work. A third is gone.

| Method | Status | How it works |
|---|---|---|
| File verification (文件验证) | Live | Download `baidu_verify_codeva-<CODE>.html`, drop it in the document root, serve it as a static file with a 200 response and no redirect |
| HTML tag verification (HTML标签验证) | Live | Put `<meta name="baidu-site-verification" content="<CODE>" />` in the homepage `<head>`, in the server-delivered HTML |
| CNAME verification (CNAME验证) | Suspended since Q1 2023 | Baidu paused it. Sites already verified this way were grandfathered |

> 近期百度搜索资源平台策略调整，站点管理-验证网站暂停【CNAME验证】的方式。该调整对已完成验证的站点没有影响。
> Baidu Search Resource Platform announcement, February 2023

Most English-language guides still list CNAME as one of three options. They are wrong, and have been for three years.

Scoping follows Baidu's own logic, not Google's. Protocol is part of the site identity, so `http://` and `https://` are separate properties. The www and non-www hosts are separate. Subdomains can be batch-added under a verified root domain and inherit ownership. There is no evidence Baidu supports registering a bare subdirectory as an independent site.

## The part nobody writes about: real-name verification

The verification file is trivial. The Baidu account is not.

- A mainland mobile number is effectively required. Baidu stopped accepting most overseas numbers around May 2022, and coverage since then is arbitrary. European numbers are reported as unsupported.
- Real-name verification (实名认证) is the hard gate. Baidu's accepted personal documents are the mainland ID card, the foreign permanent resident card, the passport of Chinese citizens residing abroad, and the mainland travel permit for Hong Kong, Macau and Taiwan residents. An ordinary foreign passport is not on the list.
- Enterprise verification needs a unified social credit code (统一社会信用代码), meaning a Chinese entity.

Two 2023 notices turned this from paperwork into a business risk:

> 关于搜索资源平台清退风险资源验证关系的通知
> Baidu Search Resource Platform, September 4, 2023

That one revoked verification relationships for accounts without real-name verification. Eighteen days later Baidu recalled submission quotas from the same cohort, shutting off sitemap access and cutting API push allowances. A site that was fine in 2022 could wake up in December 2023 with no sitemap tool and a 100 URL per day push quota.

The practical consequence: whoever real-name verifies the account effectively owns the search property. Baidu says so itself, warning enterprises not to register under an employee's personal identity because 实名认证直接影响账号和资源的归属. Agencies that register client sites under the agency's own entity are holding an asset the client cannot easily take back. There is no documented ownership transfer flow. The only real recovery path is re-verifying the domain under a new account, which works because control of the file or the meta tag is control of the domain.

## What verification unlocks, and what quietly disappeared

Verification opens crawl diagnosis (抓取诊断), crawl frequency, index volume (索引量), traffic and keywords, dead link submission, site revision, mobile adaptation, HTTPS certification, site attributes including the ICP number field, and standard submission (普通收录).

Standard submission has three channels. Manual submission caps at 20 links. API push posts to `data.zz.baidu.com/urls` with a site token and returns a remaining quota. Automatic JavaScript push is open only to sites with an associated legal entity (关联主体), which is another Chinese entity gate. Sitemap submission is not a feature for everyone, its a privilege that new and non-real-name sites do not get.

The biggest change most guides missed:

> 资源平台于 4 月 26 日下线「快速收录」工具，上新「快速抓取」工具。
> Baidu Search Resource Platform, April 2024

Fast inclusion (快速收录) was taken offline on April 26, 2024 and replaced with fast crawl (快速抓取), which is restricted to VIP club sites. Reported VIP criteria include real-name verification, ICP filing, more than a year of operating history and more than 10,000 average daily clicks across mobile and desktop. A new site belonging to a foreign brand qualifies for none of it. API push and manual submission are the whole toolkit.

Note the lineage, because clients ask about all three: Xiongzhang ID (熊掌ID) died in March 2020, its day-level inclusion privilege folded into fast inclusion, and fast inclusion died in April 2024.

## Failure modes worth knowing

- 301 or 302 on the homepage. Baidu does not follow redirect chains during verification.
- robots.txt blocking Baiduspider, or a WAF doing it silently. There is a documented Cloudflare community thread where the verification file resolves publicly but Baidu reports an I/O timeout, closed with no resolution. Whitelist by reverse DNS, not user agent: real Baiduspider IPs resolve to `*.baidu.com` or `*.baidu.jp`.
- JavaScript-rendered homepages. Baidu renders far less reliably then Google. The meta tag has to be in the initial HTML payload.
- Sites unreachable from inside mainland China. Baidu resolves and fetches from China, so a site that looks perfect from Paris can fail silently.
- Accounts without real-name verification, which is the 2023-era failure mode none of the older guides mention.

ICP filing is not a formal prerequisite for verification or indexing. It is a prerequisite for VIP privileges, for mainland hosting, and for being taken seriously by the crawler.

<!-- SECTION 2 -->

# Part 2. Baidu Merchant Center (BMC)

## What it is

BMC is Baidu Merchant Center (百度商品中心). Baidu's own definition:

> Baidu Merchant Center，简称BMC，作为百度服务商家存储结构化信息的管理系统，提供数据收录、存储、管理和输出应用的服务。
> Baidu Marketing Academy, product page 90

Baidu's product strategy team describes it more bluntly as the place where 投放物料, delivery creative material, lives for dynamic product ads. That single word settles the question of what BMC is for.

It sits under the Baidu advertising account system (百度营销 / 百度推广), not under the Search Resource Platform and not under Baidu Intelligent Cloud. The console lives at `shantou.baidu.com/bmc/` and `product.baidu.com`. Permission is a toggle on an existing ads account: key accounts get it by default, everyone else applies through a regional manager.

Name collision worth flagging before it causes an embarrassing draft: in May 2026 Baidu announced its Model Committee, also abbreviated BMC. Searching the acronym in Chinese now returns mostly that.

## The data model

Catalogs (目录) hold product files, product files hold products, and product groups are filtered slices used as ad targeting units. A new account gets three catalogs. A product file caps at one million products. A product group should stay under 100,000.

Ingestion happens five ways: manual entry for under 100 products, manual upload (Excel up to 10MB, XML or CSV up to 50MB), scheduled file sync (XML or CSV up to 8GB, requires whitelisting Baidu's IP ranges on your server), API integration, and custom crawling, which Baidu itself does not recommend. Sync frequency runs from every 15 minutes to weekly. There are 11 industry templates, and the full field dictionary sits behind a login.

Confirmed field rules that break real integrations:

- `outerid` is the unique product key, unique per catalog. Duplicates fail silently: the later upload just does not import.
- `loc` must include the protocol, and no URL may contain Chinese characters. A WooCommerce store localized into Chinese produces `/产品/` permalinks by default, which means every product row fails.
- The feed domain must match the advertiser account's registered domain.
- Optional fields can be blank or deleted but must never be filled with `0`.
- Main images have a documented floor of 480 by 320 pixels.

## Where BMC data actually goes, and this is the finding that matters

Baidu's own FAQ gives the complete output list:

> 在BMC接入的商品数据，可用于搜索/信息流动态商品广告的投放和阿拉丁推广。
> Baidu Marketing Academy, product FAQ 2612

Three destinations: search dynamic product ads, feed dynamic product ads, and paid Aladdin placements. All three are paid. There is no documented path from BMC into organic Baidu results, into Baidu AI search, or into ERNIE answers.

I checked every plausible organic route and they are all closed. Baidu's structured data tool at `zhanzhang.baidu.com/schema` was invite-only from launch in 2013, never supported a product type, and now returns a 502. Baidu has never published schema.org support. The current Search Resource Platform tool navigation contains no structured data or product feed tool at all. OpenCard, the live successor to Aladdin cards, is a real organic structured data channel that renders rich cards from a query-time webhook, but its eligibility rule explicitly excludes shopping platforms, and none of its roughly 120 open categories is retail. The Baidu transaction open platform still advertises Xiongzhang and Nuomi, both dead.

So: BMC is an advertising product wearing the clothing of a data platform. Treat "get your products into BMC" as a media buying decision, not an SEO one.

## Maintenance status

No shutdown notice exists and the console still serves. But the last article Baidu published under the dynamic product ads tag is dated January 4, 2021, and it announced consolidation into the unified marketing platform. The two canonical BMC documents date to August 2019. Baidu's entire 2025 and 2026 commercial narrative is merchant agents, AI creative generation and new search, and does not name the product once.

> Baidu's legacy business, primarily traditional search and feed advertising, fell 29% year over year to RMB 10.2 billion in the first quarter of 2026, while its AI-powered business grew 49% to RMB 13.6 billion.
> Baidu Inc., first quarter 2026 results, May 18, 2026

Read that alongside a product with no documentation updates in five years and the conclusion writes itself.

## For a foreign brand with a mainland site

BMC is almost certainly the wrong door. It requires a Baidu ads account, which requires a mainland business license or an agency sub-account or a Baidu International account for qualifying overseas entities, plus a deposit around RMB 5,000 to 6,000 and a daily budget floor of RMB 100. It buys creative automation for advertisers with hundreds of SKUs. It buys zero organic visibility.

The B2B alternative that actually occupies organic-looking real estate is Baidu Aicaigou (百度爱采购), which sits in the top slots for commercial queries, costs roughly RMB 6,980 a year for standard membership plus cost per click, and requires entering through an authorized service provider.

<!-- SECTION 3: POSITIONING -->

# Part 3. How this fits the guide

The two topics are the same story told from opposite ends. Verification is the free, organic, technical door into Baidu, and its gated by identity rather than by code. BMC is the paid, commercial door, and its gated by a mainland ad account. Foreign companies routinely confuse the two, spend money on the second, and never complete the first.

That confusion is the editorial angle. Nothing on the current guide covers either. The guide has Baidu SEO, keyword research, search engines beyond Baidu and ICP filing, but nothing on the platform where Baidu SEO is actually operated.

<!-- SECTION 4: PROPOSED ARTICLES -->

# Part 4. Proposed articles

Ranked by priority. Metadata is within the hard ceilings: title 52 characters, meta description 152 characters, excerpt 25 words.

## 1. Baidu Search Resource Platform: setup and verification

Category: Search. Flagship piece, the one that should exist first.

Angle: the ten-minute technical job versus the six-week identity job. Walk file and tag verification, kill CNAME on sight, then spend the back half on the account problem, because that is what actually blocks readers.

Covers: the two live methods, protocol and subdomain scoping, the real-name document list, why an ordinary passport fails, enterprise verification, adding collaborators, who ends up owning the property.

Keywords: baidu search resource platform, baidu webmaster tools verification, baidu site verification

- Title: Baidu Search Resource Platform: Verify Your Site
- Meta: Two verification methods still work on Baidu's webmaster platform. The harder problem is the Chinese account behind them. Here is the full process.
- Excerpt: How to verify a site on Baidu's webmaster platform, and why the account is harder than the code.

## 2. Getting indexed by Baidu in 2026

Category: Search. The natural sequel, and the piece that corrects the most outdated advice on the English web.

Angle: fast inclusion is dead, sitemap access is a privilege, here is what still works. Every competitor guide still tells readers to use tools Baidu removed.

Covers: the April 2024 replacement of fast inclusion with VIP-gated fast crawl, the September 2023 quota recall, API push mechanics and quota reality, the 20-link manual cap, why automatic push needs an associated entity, realistic timelines of two to four weeks to first indexing.

Keywords: baidu indexing, submit website to baidu, baidu fast crawl

- Title: How to Get Indexed by Baidu in 2026
- Meta: Baidu killed fast inclusion in 2024 and locked sitemaps behind quotas. Here is what still gets a foreign company's pages into the index.
- Excerpt: Fast inclusion is gone and sitemap access is a privilege. What actually gets pages into Baidu now.

## 3. Why Baiduspider cannot reach your site

Category: Technology. Strong piece, almost no competition, and it converts because it names a problem the reader's developer already has.

Angle: your site is fine everywhere except from inside China. Cloudflare, WAF rules, geo-blocking and JavaScript rendering all block the crawler quietly.

Covers: verifying Baiduspider by reverse DNS rather then user agent, the documented Cloudflare failure case, bot rules that block mainland IP ranges by default, redirect chains, server-side rendering, crawl diagnosis as the debugging tool.

Keywords: baiduspider blocked, baiduspider cloudflare, baidu crawler china

- Title: Why Baiduspider Cannot Reach Your Website
- Meta: Cloudflare rules, WAF defaults and JavaScript rendering block Baidu's crawler silently. How to spot it, verify the spider, and open the door.
- Excerpt: Cloudflare and WAF defaults block Baidu's crawler silently. How to detect it and fix it properly.

## 4. Who owns your Baidu account

Category: Legal. The commercially sharpest piece on the list.

Angle: real-name verification is an ownership record. If your agency registered your search property under its own license, the agency owns it.

Covers: the September 2023 notices, why Baidu warns against personal registration for companies, the missing transfer flow, why re-verification is the only recovery, what to write into an agency contract, the collaborator model as the correct arrangement.

Keywords: baidu account ownership, baidu real name verification, china seo agency risk

- Title: Who Really Owns Your Baidu Account?
- Meta: Real-name verification decides who owns your Baidu search property. Foreign brands often discover their agency holds it. How to structure it properly.
- Excerpt: Real-name verification decides who owns your Baidu property. Often it is not the brand paying for it.

## 5. Baidu Merchant Center explained

Category: Search. The BMC piece, framed as a myth correction.

Angle: BMC is an ads product, not an SEO product. Anyone selling it as a route to organic product visibility is selling media.

Covers: what BMC is, the catalog and product file model, the five ingestion methods, the field rules that break WooCommerce exports, the three paid destinations, the absence of any organic path, the 2021 documentation freeze, the Model Committee name collision.

Keywords: baidu merchant center, baidu product feed, baidu dpa

- Title: Baidu Merchant Center: What BMC Actually Does
- Meta: BMC stores product feeds for Baidu's dynamic product ads. It is a media product, not an SEO one, and no organic path out of it exists.
- Excerpt: BMC feeds Baidu's dynamic product ads. It is a media buy, not a route to organic visibility.

## 6. Baidu structured data is mostly dead

Category: Technology. Good linkbait for technical readers, and it kills a persistent client request.

Angle: everything a Google-trained developer reaches for does not exist here. Baidu never supported schema.org, its own structured data tool is a 502, and the live replacement bars retail.

Covers: the 2013 structured data tool and its death, no schema.org spec or validator, OpenCard mechanics and its shopping exclusion, mini programs, what markup is still worth shipping and why.

Keywords: baidu structured data, baidu schema markup, baidu rich results

- Title: Baidu Structured Data: What Still Works
- Meta: Baidu never supported schema.org, retired its structured data tool, and bars retail from OpenCard. What is left, and what to ship anyway.
- Excerpt: Baidu never supported schema.org and retired its own tool. What structured data still earns anything.

## 7. Registering a Baidu account from outside China

Category: Legal. Narrow, high intent, ranks easily.

Angle: the phone number is the famous problem, the identity document is the real one.

Covers: which country codes work and which do not, why virtual numbers are a liability now that quotas depend on real-name status, the accepted document list, the enterprise route through a mainland entity, the agency route and what to negotiate.

Keywords: baidu account outside china, baidu webmaster account foreign company

- Title: Register a Baidu Account From Outside China
- Meta: A Chinese mobile number is the famous obstacle. The identity document requirement is the real one. Every route foreign companies actually use.
- Excerpt: The phone number is the famous obstacle. The identity document is the one that actually blocks you.

## 8. Baidu Aicaigou for B2B

Category: Search. Fills a real gap: the guide has nothing B2B specific.

Angle: for commercial queries, the top of a Baidu results page is often not organic at all, and B2B buyers land inside a marketplace rather then on your site.

Covers: how listings occupy commercial SERPs, membership pricing and the service provider requirement, what qualifies a supplier, when it beats building organic rankings, how it interacts with a company site.

Keywords: baidu aicaigou, baidu b2b, china b2b search

- Title: Baidu Aicaigou: B2B Search in China
- Meta: For commercial queries, Baidu's top results are often marketplace listings. How Aicaigou works, what it costs, and when it beats organic SEO.
- Excerpt: Baidu's top commercial results are often marketplace listings. How Aicaigou works and when it beats SEO.

## Internal linking

Articles 1, 2, 3 and 7 form the platform cluster and should link to each other and out to the existing ICP filing and hosting pieces. Article 4 links to the agency vetting piece. Articles 5, 6 and 8 form the commercial cluster and link to the WooCommerce piece. The existing Baidu SEO page should become the hub linking down to 1 and 2.

## Two things to check before publishing

Fast crawl VIP criteria (the 10,000 daily click threshold) come from Chinese practitioner blogs, not a Baidu announcement. Aicaigou pricing comes from a 2022 blog re-confirmed by a Baidu partner page. Both are worth a fresh check on publication day. A cluster of 2026 articles claiming a platform redesign with new quotas traces to a single domain and does not survive scrutiny. It was excluded.

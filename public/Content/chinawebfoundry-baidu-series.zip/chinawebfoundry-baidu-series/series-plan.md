---
title: "Baidu Platform and BMC: Two Article Series"
slug: baidu-platform-bmc-article-series
description: "Sixteen narrow guide articles across two series covering Baidu Search Resource Platform verification and Baidu Merchant Center distribution."
excerpt: "Two clusters of short, narrow articles: the Baidu webmaster platform, and Baidu's commercial distribution products."
template: internal-brief
---

<!-- STRUCTURE NOTE -->

Sixteen articles, two clusters, each piece narrow enough to answer one question at around 700 words. Nothing here duplicates the existing 13 entries on the guide. Publication order runs top to bottom inside each series, because each piece assumes the one above it.

<!-- SERIES A -->

# Series A. The Baidu Search Resource Platform

Ten articles. The spine of the guide's Search category, and the cluster that currently has no coverage at all.

## A1. What the Baidu Search Resource Platform is

Category: Search

Orientation piece and cluster hub. What the platform does, what it is called (百度搜索资源平台, formerly 百度站长平台), where it sits relative to Baidu Tongji (百度统计) and Baidu Index (百度指数), and a map of its live modules. Ends with the graveyard, because clients still ask about all three: Xiongzhang ID (熊掌ID) dead March 2020, structured data tool dead, fast inclusion dead April 2024.

Keyword: baidu search resource platform

- Title: What Is the Baidu Search Resource Platform?
- Meta: Baidu's webmaster platform is where China SEO is actually operated. What each module does, and which three famous tools no longer exist.
- Excerpt: Baidu's webmaster platform, module by module, plus the three well known tools that no longer exist.

## A2. Getting a Baidu account as a foreign company

Category: Legal

The phone number is the famous obstacle. The identity document is the real one. Covers which country codes still receive the SMS, why virtual numbers became a liability after 2023, Baidu's accepted document list for real-name verification (实名认证), why an ordinary foreign passport is not on it, and the enterprise route through a unified social credit code (统一社会信用代码).

Keyword: baidu account outside china

- Title: Getting a Baidu Account as a Foreign Company
- Meta: A Chinese mobile number is the obstacle everyone talks about. The identity document requirement is the one that actually stops foreign brands.
- Excerpt: The phone number is the obstacle everyone mentions. The identity document is the one that stops you.

## A3. Verifying your site: file or HTML tag

Category: Search

The pure how-to. Exact file name pattern, where the document root lives on the common Chinese and Hong Kong hosts, the meta tag and where it goes, why the tag has to be in server-delivered HTML, and why Baidu re-checks later so nobody deletes the file after launch. One paragraph kills CNAME verification, suspended since Q1 2023 and still listed in most English guides.

Keyword: baidu site verification

- Title: Verify Your Site on Baidu: File or HTML Tag
- Meta: Two verification methods still work on Baidu's webmaster platform. Exact file names, tag placement, and why CNAME verification no longer exists.
- Excerpt: The two verification methods that still work, step by step, and the third one Baidu suspended.

## A4. What counts as one site: www, HTTPS and subdomains

Category: Search

The scoping rules that surprise everyone coming from Google Search Console. Protocol is part of site identity, so the http and https versions are separate properties. Www and non-www are separate hosts. Subdomains batch-add under a verified root and inherit ownership. Subdirectories cannot be registered as independent sites, which matters for anyone planning a /cn/ folder.

Keyword: baidu webmaster subdomain verification

- Title: Baidu Verification: www, HTTPS and Subdomains
- Meta: Baidu treats protocol and host as part of site identity. What counts as one property, what needs separate verification, and what cannot be added.
- Excerpt: Protocol and host are part of site identity on Baidu. What needs separate verification and what does not.

## A5. Verification failed: the usual causes

Category: Search

Troubleshooting piece, structured as a table of symptom, cause and fix. Homepage 301 and 302 redirects, robots.txt, JavaScript-rendered homepages, the site being unreachable from inside mainland China, stale DNS resolution, 403 responses, and the 2023-era failure nobody documents: an account that never completed real-name verification losing its verification relationship.

Keyword: baidu verification failed

- Title: Baidu Site Verification Failed: The Usual Causes
- Meta: Redirects, robots.txt, JavaScript homepages and unverified accounts all break Baidu verification quietly. Each symptom, its cause, and the fix.
- Excerpt: Every common reason Baidu verification fails, what each looks like, and how to fix it.

## A6. Baiduspider and your firewall

Category: Technology

The strongest technical piece in the series and the one with almost no competition. Your site is fine everywhere except from inside China. Cloudflare rules and WAF defaults block the crawler silently, including a documented community case where the verification file resolves publicly and Baidu still reports a timeout. Covers verifying the spider by reverse DNS rather than user agent, the legitimate user agent strings, and geo rules that block mainland ranges by default.

Keyword: baiduspider blocked cloudflare

- Title: Baiduspider and Your Firewall
- Meta: Cloudflare and WAF defaults block Baidu's crawler without telling you. How to detect it, verify the real spider by reverse DNS, and open the door.
- Excerpt: Cloudflare and WAF defaults block Baidu's crawler silently. How to detect it and let it through.

## A7. Submitting URLs to Baidu

Category: Search

The three channels of standard submission (普通收录) and what each is worth. API push with its endpoint, token and remaining-quota response. Manual submission capped at 20 links. Automatic JavaScript push, open only to sites with an associated legal entity (关联主体). And the awkward one: sitemap submission is a privilege rather than a feature, withdrawn from new and unverified-identity sites since September 2023.

Keyword: submit website to baidu

- Title: Submitting URLs to Baidu: Push, Sitemap, Manual
- Meta: API push, sitemap and manual submission are not equal, and sitemap access is a privilege. What a new foreign site can actually use.
- Excerpt: The three submission channels, their real quotas, and why sitemap access is a privilege not a feature.

## A8. Fast inclusion is gone

Category: Search

The correction piece. Baidu took fast inclusion (快速收录) offline on April 26, 2024 and replaced it with fast crawl (快速抓取), restricted to VIP sites. Reported criteria include real-name verification, ICP filing, more than a year of operation and more than 10,000 average daily clicks. A new foreign brand site qualifies for none of it. Nearly every English guide still recommends the dead tool.

Keyword: baidu fast crawl

- Title: Baidu Fast Inclusion Is Gone. What Replaced It
- Meta: Baidu removed fast inclusion in April 2024 and replaced it with a VIP-only fast crawl tool. Who qualifies, and what everyone else does instead.
- Excerpt: Baidu killed fast inclusion in 2024. What replaced it, who qualifies, and what the rest do.

## A9. Reading Baidu's index and traffic data

Category: Search

What the numbers mean and when they show up. Index volume (索引量) is a trend, not a count. Traffic and keywords carries roughly five hours of latency and only populates once the site earns clicks. Crawl frequency needs actual spider visits before it says anything. Realistic expectation for a new site: two to four weeks to first indexing, and empty dashboards before that are normal.

Keyword: baidu index volume

- Title: Reading Baidu's Index and Traffic Data
- Meta: Index volume is a trend, not a count, and keyword data lags by hours. What each Baidu report means and when a new site should expect numbers.
- Excerpt: What Baidu's index, crawl and keyword reports actually measure, and when a new site sees data.

## A10. Who owns your Baidu account

Category: Legal

The commercially sharpest piece in the series. Real-name verification is the ownership record, and Baidu says so itself when it warns companies against registering under an employee's identity. If an agency verified your site under its own license, the agency holds the property. There is no documented transfer flow. Covers the collaborator model as the correct arrangement, and what to put in an agency contract.

Keyword: baidu account ownership

- Title: Who Owns Your Baidu Account?
- Meta: Real-name verification decides who owns your Baidu search property. Foreign brands regularly find their agency holds it. How to structure it properly.
- Excerpt: Real-name verification decides who owns the property. Often it is not the brand paying for it.

<!-- SERIES B -->

# Series B. Baidu commercial distribution

Six articles. Where product and business data goes in China, and where it does not. This cluster ends the recurring client question about feeding a catalog into Baidu for free.

## B1. What Baidu Merchant Center is

Category: Search

BMC is Baidu Merchant Center (百度商品中心), a structured data store that sits under the Baidu advertising account system, not under the webmaster platform. Baidu's own product team calls its contents delivery creative material (投放物料), which settles the argument about what it is for. Includes the naming warning: Baidu announced a Model Committee, also abbreviated BMC, in May 2026.

Keyword: baidu merchant center

- Title: Baidu Merchant Center: What BMC Actually Does
- Meta: BMC is Baidu's product data store for advertisers. Where it lives, which account system it belongs to, and why the acronym now means two things.
- Excerpt: What Baidu Merchant Center is, which account system owns it, and why the acronym is now ambiguous.

## B2. Building a product feed for Baidu

Category: Technology

The build piece, written for a developer. Catalogs, product files and product groups, with the caps: three catalogs on a new account, one million products per file. Five ingestion methods from manual entry to scheduled sync with IP whitelisting. Then the field rules that silently break real integrations, including the unique key whose duplicates fail without warning, and the ban on Chinese characters anywhere in a URL, which breaks a Chinese-localized WooCommerce store by default.

Keyword: baidu product feed

- Title: Building a Product Feed for Baidu
- Meta: Catalog limits, ingestion methods and the field rules that break WooCommerce exports, including the URL rule nobody discovers until the feed fails.
- Excerpt: How a Baidu product feed is structured, and the field rules that quietly break WooCommerce exports.

## B3. Where Baidu product data actually goes

Category: Search

The myth correction, and the reason this series exists. Baidu documents exactly three destinations for merchant data: search dynamic product ads, feed dynamic product ads and paid Aladdin placements. All three are paid. No organic path is documented, and every plausible one is closed. Anyone selling a product feed as a route to free visibility is selling media.

Keyword: baidu dpa

- Title: Where Baidu Product Feed Data Actually Goes
- Meta: Baidu documents three destinations for merchant product data, and all of them are paid placements. There is no free route into organic results.
- Excerpt: Baidu documents three destinations for merchant data. All three are ads. There is no organic route.

## B4. A Baidu ads account without a Chinese entity

Category: Legal

The prerequisite piece for anything in this series. Two documented routes: a sub-account under a certified reseller's license, or a Baidu International account for entities registered in qualifying jurisdictions. Covers deposits, daily budget floors, the documents each route wants, approval timelines, and the trade-off that dropping the mainland entity usually means dropping mainland hosting too.

Keyword: baidu ads account foreign company

- Title: A Baidu Ads Account Without a Chinese Entity
- Meta: Two routes exist for foreign companies: a reseller sub-account or a Baidu International account. What each requires, costs, and gives up.
- Excerpt: The two routes foreign companies use to open a Baidu ads account, and what each one costs.

## B5. Baidu structured data: what still works

Category: Technology

Everything a Google-trained developer reaches for is either absent or dead here. Baidu never published schema.org support or a validator. Its own structured data tool was invite-only from 2013 and now returns a server error. The live successor, OpenCard, renders rich cards from a query-time webhook but explicitly excludes shopping platforms from eligibility. Ends with what is still worth shipping and why.

Keyword: baidu structured data

- Title: Baidu Structured Data: What Still Works
- Meta: Baidu never supported schema.org, retired its own structured data tool, and bars retail from OpenCard. What is left, and what to ship anyway.
- Excerpt: Baidu never supported schema.org and retired its own tool. What structured data still earns anything.

## B6. Baidu Aicaigou for B2B

Category: Search

Fills a real gap, since nothing on the guide is B2B specific. For commercial queries the top of a Baidu results page is often not organic at all, and the buyer lands inside a marketplace rather than on the supplier's site. Covers how listings occupy those slots, membership tiers and the authorized service provider requirement, supplier qualification, and when this beats building organic rankings.

Keyword: baidu aicaigou

- Title: Baidu Aicaigou: B2B Search in China
- Meta: For commercial queries, Baidu's top results are often marketplace listings. How Aicaigou works, what it costs, and when it beats organic SEO.
- Excerpt: Baidu's top commercial results are often marketplace listings. How Aicaigou works and when it wins.

<!-- LINKING AND SEQUENCING -->

# Linking and sequencing

A1 is the hub for Series A and should be linked from the existing Baidu SEO page. A2 and A10 pair, so link them both ways: one covers getting the account, the other covers who ends up owning it. A3, A4 and A5 form the verification run and belong in a next-and-previous chain. A6 links out to the existing Great Firewall and hosting pieces. A7, A8 and A9 form the indexing run, with A8 linking back to A7 for what to do instead.

B1 is the hub for Series B. B4 is a prerequisite for B1, B2 and B3, so link it up from each. B2 links to the existing WooCommerce piece, B5 links to A6 and A7 since both are technical crawl topics, and B6 links to the existing Baidu SEO and keyword research pieces.

Bridge between the series: A7 and B3 answer the same underlying question, how content reaches Baidu users, from the free side and the paid side. Link them to each other.

# Publication order

Ship A1 through A5 first as a block, since verification is the highest-intent search demand and nothing on the guide serves it. A6 next, because it is the most linkable piece in either series. Then A7 through A10. Series B follows, led by B3 rather than B1, because the myth correction is the piece with an actual audience and B1 reads better as its follow-up.

# Two things to check on publication day

The fast crawl VIP criteria in A8, including the 10,000 daily click threshold, come from Chinese practitioner blogs rather than a Baidu announcement. Aicaigou pricing in B6 comes from a 2022 blog re-confirmed against a Baidu partner page. Both are worth a fresh look before either piece goes live.

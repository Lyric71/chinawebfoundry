# Iteration 8: SEO metadata

Primary keyword: baidu index volume
Secondary: baidu traffic and keywords, baidu crawl diagnosis, baidu indexing timeline

## title (45 / 52)
Reading Baidu's Index Volume and Traffic Data

Carries the exact primary keyword in natural word order. "Reading" signals interpretation rather than a definition page, which separates it from A1 in the same guide.

## description (139 / 152)
What Baidu's index volume, traffic and keyword reports actually measure, how far to trust each one, and when a new site should expect data.

Three-part promise matching the article's actual structure. "Should expect data" targets the searcher whose dashboard is empty.

## excerpt (25 / 25 words)
Baidu index volume is a trend line, not a count. What each report measures, how far to trust it, and when new sites see data.

Leads on the single most useful correction in the piece.

## Notes
- Primary keyword appears in the H1, in the first H2, and in the opening of the index volume section. No stuffing beyond that.
- Rejected title "Baidu Index Volume Explained" (28 chars): keyword-first but generic, and it drops the traffic-data half of the article.
- Rejected excerpt phrasing "when zeros end" (24 words): punchy but under the required 25.

# Iteration 15: structural smell test

**Section balance.** Seven H2s over roughly 1,200 words. Index volume 170, traffic and keywords 250, crawl reports 160, diagnosis and dead links 190, contradictions 260, timeline 170. The contradictions section is the longest and that is correct, since it is the section the brief singles out and the one with no equivalent anywhere else in the guide.

**Heading test.** Each H2 asserts something rather than naming a category. "Crawl frequency and crawl exceptions need a spider first" is the weakest of the six, but it is still a claim, and the alternative phrasings all drifted toward labels.

**Does anything belong somewhere else?** Dead link submission is the only tool in the piece that is not a report. It sits under the diagnosis heading because both are things you do rather than things you read, and cutting it would drop a required fact. Kept, but the heading was checked for honesty and covers it.

**Order.** Index volume first because it is the number that triggers the panic. Traffic second because it is the one that stays empty longest. Crawl reports third because that is where the diagnosis actually starts. Contradictions and timeline last because both depend on the reader knowing what the earlier reports are.

**Fixed here.** The line "Fewer dimensions, shorter retention, and the estimates arrive with no sense of how rough they might be" had drifted back toward the rule of three that iteration 13 broke. Rewritten again, this time as two clauses of unequal weight.

**Also fixed.** Two adjacent paragraphs in the traffic section both opened with a bare noun subject ("Measurement is hourly", "Retention is the real constraint"). Varied the first.

No summary section, no conclusion, no closing recap. The piece ends on the SLA point, then the maintenance line, then the CTA.

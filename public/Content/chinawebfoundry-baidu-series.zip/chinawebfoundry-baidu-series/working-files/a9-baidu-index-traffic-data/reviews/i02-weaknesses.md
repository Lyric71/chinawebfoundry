# Iteration 2: ten weaknesses in v1

1. **Over length.** 1,412 words against a 900 to 1,200 target. Roughly 200 to 250 words must come out without losing any required fact.

2. **Fact-base risk on the 1,000-link exceptions limit.** The brief requires it, but FACTS.md does not carry it. Current phrasing ("is reported to be limited") is acceptable but sits awkwardly. Needs a cleaner hedge that reads like journalism, not like a disclaimer.

3. **Invented benchmark.** "If the figure moves 3% overnight, that is noise" is a fabricated threshold. The brief explicitly forbids inventing benchmark figures. Must be removed and replaced with a non-numeric formulation.

4. **Invented example numbers.** "Index volume says 4,000 pages, your sitemap says 9,000" and "a site that has just broken 40,000 URLs" read as data. They are illustrative, but a hostile reader will treat them as claims. Recast as unnumbered scenarios.

5. **The StatCounter blockquote is bolted on.** Market share has nothing to do with reading traffic reports. The statistic is approved but the placement is decorative. Either cut it or replace it with one that earns its place in an article about measurement.

6. **Only one blockquote in a 1,400-word piece.** The style reference carries two or three, spaced through the piece. The article needs a second citation moment, and the AI-content statistic is genuinely relevant to why click data underperforms impression expectations.

7. **"Nobody does this and everybody regrets it" is a rhetorical tic.** Balanced negative-positive pair, the exact cadence an AI tell detector flags. Same problem with "absence of evidence rather than evidence of a problem," which is a borrowed aphorism doing the work a plain sentence should do.

8. **The reliability-order paragraph is a list wearing prose clothing.** Four sentences in identical shape, each naming a tool then rating it. Mechanical.

9. **No pinyin on two Chinese terms.** 流量与关键词 and 死链提交 appear with characters but no pinyin, and the house rule requires English term (characters, pinyin with tone marks) on first use. The validation script will flag both.

10. **The closing section ends on a too-clever line.** "Anyone telling you they can guarantee an indexing date is selling something" is a punchline, not a finding. It also edges toward a conclusion, which the brief forbids. The piece should end on substance.

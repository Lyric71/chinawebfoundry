# Iteration 11: hostile-reader re-read, ten issues

Reading as a skeptical in-house marketer who has the platform open in another tab.

1. **"Anyone arriving from Search Console gets three surprises."** The section then delivers four (hourly clock with five-hour lag, retention, the row cap, the empty-until-clicks rule). Promising a count and missing it is the kind of thing a careful reader notices immediately. Cut the count.

2. **"A drop that holds for a fortnight."** British. The brief mandates American English. Change to two weeks.

3. **The traffic and keywords section never says what the report contains.** It jumps straight to clocks and limits. A reader who has never opened it does not learn that it reports impressions and clicks against queries. Add that in the opening sentence.

4. **The 50,000-row cap is unexplained.** Rows of what? A reader reasonably assumes URLs. They are keyword rows. Say so.

5. **"Index volume sits below your sitemap count."** Stated as a certainty about the reader's site. It is a common pattern, not a law. Hedge to "usually sits below".

6. **"The tail gets cut with no warning on screen."** That is a claim about Baidu's interface behavior that is not in the fact base. Soften to describe the consequence rather than the UI.

7. **The crawl frequency report is described only in the negative.** The section explains what a flat line means and never says what the report is for once the spider does arrive. One clause fixes it.

8. **"Click data comes next, a click being a concrete event."** Absolute construction, stiff, and the second clause explains something obvious. Rewrite plainly.

9. **The 1,000-link limit hedge is too soft to be useful.** "Practitioner documentation puts that list at" tells the reader nothing about how much weight to give it. Make the uncertainty explicit and actionable: check it against your own site.

10. **Word count.** 1,213 body words against a 1,200 ceiling. Thirteen words over, which the fixes above should absorb rather than add to.

# Iteration 13: AI-tell pattern hunt

Scanned v12 for rhetorical triads, anaphoric pairs, balanced antitheses and buzzwords. Six candidates found, four broken. The hero's "Index volume: zero. Traffic and keywords: empty. Crawl frequency: a flat line." is a triad but it is a screen the reader is literally looking at, so it stays. "Not which pages. Not an exact count either" was left because the second clause already breaks the parallel with "either, and Baidu has never presented it as one."

## Broken

**1. Rule-of-three list.** "Fewer dimensions, shorter retention, estimates offered with no sense of how rough they are." Three items in descending rhythm, the single most common AI cadence in analytical copy. Rewritten as an uneven two-part sentence with the third item demoted into a subordinate clause.

**2. Anaphoric pair.** "No committed crawl interval, no promised indexing window." Two negations in identical shape. Rewritten so the second half changes grammatical footing instead of mirroring the first.

**3. Balanced antithesis.** "On a brochure site that ceiling is theoretical. On a large catalog it is not." Textbook A-then-not-A construction with matched sentence length. Rewritten so the two cases are unequal in length and the second one carries the consequence.

**4. Ranked-list parallelism.** "Click data comes next. Index volume is directional." Two clipped declaratives of near-identical length inside the confidence ranking, which made the whole paragraph read like a scored table. Merged and varied.

## Left alone, with reasons
- Hero triad: mirrors the actual dashboard, earns its symmetry.
- "Firewall and hosting, in other words, not editorial." Fragment, but it is the kind of thing a practitioner says out loud.

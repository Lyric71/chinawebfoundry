# Iteration 4: production-ready review

**Verdict: not production ready. One blocking issue, three minor.**

Blocking: length. v3 measures 1,381 body words against a hard 900 to 1,200 target. That is 180 words over the ceiling and it has to come out of the copy, not the facts.

Minor issues found and fixed in v4:

1. Length. Cut 190 words across every section. Removed the second half of the intro (redundant with the hero), compressed the subdomain note, folded the "no point refreshing at lunchtime" aside into the sentence before it, and trimmed the reliability-order paragraph. No approved fact was dropped.
2. The line "Some of that is deliberate and some of it is neglect" is speculation about Baidu's intent and is not supported by anything in the fact base. Cut.
3. "Most teams work this out in month eleven" is an invented specific. Replaced with an unnumbered version.
4. The RMB blockquote plus its two-sentence follow-up carried more weight than the point needed. Follow-up cut to one sentence.

Fact check against the approved base, all present and correctly stated: daily-for-a-year and monthly-beyond granularity; trend not count; hourly measurement; roughly five hours latency; 30-day keyword window; 50,000 rows; three-month mobile retention; empty until clicks; 200KB crawl diagnosis cap; the 70 versus 200 weekly quota conflict, attributed to both sources by name; dead link submission at 50,000 URLs and 10MB with three days to a week removal; verification instant to 24 hours; initial indexing two to four weeks; index volume zero for days to weeks; no SLA; root-domain verification for subdomain index data; ICP number in site attributes for sites under six months.

Outside the approved base and hedged as such: the first-1,000-links limit on crawl exceptions, attributed to practitioner documentation rather than to Baidu.

Structure: one H1, seven H2s, no summary section, maintenance line and CTA present. Zero em dashes. No markdown links, no URLs, no HTML in body.

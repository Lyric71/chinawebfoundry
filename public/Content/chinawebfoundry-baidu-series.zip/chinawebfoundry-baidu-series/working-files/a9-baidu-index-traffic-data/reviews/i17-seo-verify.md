# Iteration 17: measured verification

title: 45 / 52 characters
description: 139 / 152 characters
excerpt: 25 / 25 words exactly
body: 1,201 words with editorial comments stripped (1,247 by the shared check script, which counts comment text). Inside the 900 to 1,200 target.
em dashes: 0. En dashes: 0.
structure: one H1, six H2s, no summary or conclusion section.
blockquotes: one statistic, two lines, claim then attribution.
markdown links: 0. URLs in body: 0. HTML in body: 0 (section labels are comments only).
CTA present and exact. Maintenance line present and dated August 2026.
Chinese terms carry characters plus pinyin with tone marks on first use: 百度搜索资源平台, 索引量, 流量与关键词, 抓取诊断, 死链提交, 百度统计, 备案号. 优化猩 appears as a source name, not a term, so it takes no gloss.
Frontmatter keys: exactly the five required, template guide-article.
Shared check script: OK, no issues flagged.

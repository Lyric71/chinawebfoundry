# Iteration 11: hostile-reader re-read (a skeptical senior developer)

Ten issues found, all fixed in v11.

1. **"The other two ceilings" names one.** The sentence promises two figures and delivers only the million-product file cap. The second ceiling (100,000 per product group) is not generous and appears two paragraphs later. Rewritten so each cap is stated once, in its own place.

2. **"API integration is the fourth route" is content-free.** A developer scoping a build stops on that line and asks: which protocol, what auth, what payload. We have no approved facts on any of it. Fixed by saying so honestly rather than padding the sentence.

3. **Scheduled sync formats are ambiguous.** Excel is named under manual upload, then sync is described without stating that it takes XML and CSV only. A reader could reasonably assume the 8GB ceiling applies to a spreadsheet. Made explicit.

4. **Subhead overclaims.** "Two defaults that fail every row" is true of permalinks and false of variations, which fail a subset. Subhead rewritten.

5. **The statistic floats.** 937 million online shoppers is followed by "That is the market on the far side of the file," but the file only reaches that market through paid placements. The link needed one clause of connective tissue.

6. **"Three containers" subhead, four objects in the section.** Product group is the fourth thing described. Subhead adjusted to stop fighting the content.

7. **The sequence section reads like a banned summary.** Fix URLs, settle outerid, upload manually: two of those three are restatements of earlier advice. Rebuilt around the two things that actually determine calendar time, and the recap clauses cut.

8. **No consequence attached to the domain match rule.** The rule is stated, the failure mode is listed, but the reader is never told the practical implication for a company running country subdomains, which is common in this audience.

9. **"Companies rarely discourage their own features without a reason."** A knowing aside that adds no information a developer can act on. Replaced with the actionable version: treat the recommendation as a support commitment signal.

10. **Length.** 1,268 words against a 1,200 ceiling. Trimmed in the introduction, ingestion and sequence passages.

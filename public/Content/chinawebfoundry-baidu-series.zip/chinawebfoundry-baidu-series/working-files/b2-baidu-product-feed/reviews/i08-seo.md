# Iteration 8: SEO metadata

Primary keyword: baidu product feed

**title:** How to Build a Baidu Product Feed
33 characters (ceiling 52). Exact-match keyword, front-loaded after the how-to frame. Chosen over the working title "Building a Product Feed for Baidu" (33 chars) because that phrasing splits the keyword across "product feed for baidu" and loses the exact string.

**description:** How a Baidu product feed is structured, the five ways to load it, and the field rules that quietly break a WooCommerce or headless export.
138 characters (ceiling 152). Carries the keyword once, plus WooCommerce and headless as secondary intent terms.

**excerpt:** No plugin builds a Baidu product feed for you. The catalog structure, the five ingestion routes, and the field rules that break a WooCommerce export.
25 words exactly. Leads with the fact that reframes the whole project estimate.

H1 updated to match the title. Slug unchanged: baidu-product-feed.

Secondary terms present in body: Baidu Merchant Center, BMC hierarchy, product file, product group, outerid, scheduled file sync, WooCommerce Baidu feed.

# Iteration 2: ten weaknesses in v1

1. **Invented template names.** "Retail, travel, property and the rest" names industries FACTS.md never lists. FACTS says only "11 industry data templates". Cut every named vertical.

2. **Invented rationale for the API route.** "for teams that want to push changes as they happen rather than wait for a fetch" is a plausible-sounding fit statement Baidu never made in the fact base. Either state the route plainly with no invented purpose, or drop the clause.

3. **The "five field rules" promise breaks.** The subhead announces five rules, then the section delivers seven items (outerid, loc, Chinese characters, domain match, zero, images, custom labels). A reader counting along loses trust. Drop the number from the subhead.

4. **Over length.** 1,431 words in file, well past the 900 to 1,200 body target. The order-of-work section and parts of the ingestion section are the softest material.

5. **Missing the WooCommerce-has-no-plugin point up top.** The brief wants it said plainly, but it lands in the eighth section. A developer scoping the work needs it in the first screen, because it changes the estimate before anything else does.

6. **Unhedged sales claim about scheduled sync.** "the one most integrations should end at" is our opinion presented as Baidu's guidance, sitting one line from actual Baidu-stated limits. Mark it as our view or cut it.

7. **Weak hero.** "Somebody has handed you a sentence" is a tic borrowed from the reference piece's construction. It also buries the concrete detail (no plugin, 2019 spec, silent failures) in a list.

8. **Chinese term formatting inconsistency.** Terms get characters plus pinyin correctly, but 商品组 appears after 商品 in a way that reads like four parallel objects when one of them is not storage. The distinction needs to be sharper, and one pinyin gloss too many slows the passage.

9. **No treatment of the whitelisting consequence.** The IP whitelist requirement is stated but its real effect (mainland WAF, Cloudflare-style blocking, the same class of problem that breaks Baiduspider verification) is left implicit. Half a sentence of consequence earns its place.

10. **The closing section is a checklist in prose clothing.** "Confirm, then pull, fix, map" is four imperatives in a row. It reads mechanical and duplicates advice already given inside the field-rules and template sections.

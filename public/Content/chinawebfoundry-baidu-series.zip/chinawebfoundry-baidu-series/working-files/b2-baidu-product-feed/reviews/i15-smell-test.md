# Iteration 15: structural smell test

**Section order.** Hierarchy, ingestion, templates, field rules, WooCommerce, calendar. That is the order a developer meets the problems in, not the order Baidu's documentation presents them. Correct as is.

**Section length balance.** Field rules runs longest, at roughly a third of the body. Appropriate: it is the section that prevents the failures, and the brief names most of those rules explicitly. Hierarchy and templates are the shortest and neither has anything left to cut.

**Smells found and fixed:**

- The introduction spends two sentences positioning the market before the piece does any work. Compressed to one.
- "Little of what goes wrong here is exotic. Most of it fails quietly, which is the part that costs you." The second clause explains the joke. Cut back to the plain observation.
- The outerid paragraph carries a redundant restatement ("the row you believed you had updated sits there with its old values" plus "when your import counts do not match"). Both stay, but the first is tightened, because that is the diagnostic detail a developer needs and the second is the symptom.
- The calendar section closed on a line about English summaries that repeated a point already made in the templates section. Cut.

**Checked and left alone:** the single blockquote (one statistic, correctly formatted, two lines); the four Chinese terms, each glossed once with characters and tone-marked pinyin on first use; the absence of any summary or conclusion section; the maintenance line and CTA.

Body length after this pass is the remaining risk, tracked into iteration 17.

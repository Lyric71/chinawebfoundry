# Iteration 17: SEO and structure verification (measured)

- title: "How to Build a Baidu Product Feed" = 33 characters (ceiling 52). PASS
- description = 138 characters (ceiling 152). PASS
- excerpt = 25 words exactly. PASS
- body word count = 1195 (target 900 to 1,200). PASS
- em dashes = 0. PASS. En dashes and minus signs also 0.
- H1 count = 1, matching the frontmatter title. H2 count = 6.
- markdown links = 0, URLs in body = 0, HTML tags in body = 0 (section labels are HTML comments only).
- blockquote = 1 statistic, two lines, claim then attribution.
- Chinese terms glossed once each with characters and tone-marked pinyin: 百度商品中心, 目录, 商品文件, 商品, 商品组.
- CTA present as a plain text label. Maintenance line present and dated August 2026.
- No summary, conclusion or recap section. The piece ends on the calendar section.
- Primary keyword "baidu product feed" appears in title, description, excerpt and slug.

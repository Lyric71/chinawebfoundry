# Iteration 4: production readiness review

**Verdict: not production ready. Three blocking issues, four trims.**

Blocking:
1. No `<!-- HERO SECTION -->` label above the H1. The brief's section-comment convention requires it, and the reference article carries it.
2. Length. 1,320 words in file against a 900 to 1,200 body target. Needs roughly 150 words out.
3. The WooCommerce section absorbed the order-of-work material in v3, so it now carries three jobs: the no-plugin statement, the two failure modes, and build sequencing. The sequencing paragraph should stand as its own short section or the section subhead lies about its contents.

Non-blocking but fixed here:
4. "in our experience" and "We tend to" both appear. The brief allows first person plural once or twice. Two is the ceiling, and one of them is doing less work than the other.
5. "Take that at face value. Companies rarely publish discouraging notes about their own features without a reason." Two sentences to make one point.
6. The headless paragraph runs long for a piece whose brief names WooCommerce specifically. Compress to two sentences.
7. "a guess dressed as a spec" is a clever construction sitting next to another one ("not a partial failure, it is every row"). Keep the stronger, plain the other.

Changes applied in v4: added the hero label; cut roughly 170 words across the introduction, ingestion and headless passages; split sequencing into its own labeled section; reduced first person to two instances; tightened the custom crawl note; simplified the templates line.

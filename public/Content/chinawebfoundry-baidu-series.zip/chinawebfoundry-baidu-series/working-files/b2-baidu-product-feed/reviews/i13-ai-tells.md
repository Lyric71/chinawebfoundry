# Iteration 13: AI-tell pattern hunt

Three patterns broken, plus two smaller ones.

1. **Self-created subhead template.** Three consecutive H2s ran on the identical "Number, and a consequence" frame: "Four objects, and the smallest allowance is the one that hurts" / "Five ways in, and Baidu argues against one of them" / "Eleven templates, and a dictionary you cannot read yet". Read in sequence it is unmistakably machine-generated cadence. Kept one, rewrote the other two on different grammar (a declarative sentence and a because-clause).

2. **Negative parallelism stacking.** "That is a firewall ticket, not a code change." / "Sync frequency is a menu rather than a number you set." / "closer to a saved segment than a folder" / "Little of what goes wrong here is exotic." Four instances of the same X-not-Y move inside 400 words. Kept the firewall one, which carries real information, and rewrote the rest as plain statements.

3. **Rhetorical triad in the variations advice.** "Build a composite key, parent plus variation, and keep it stable between exports" is a three-beat closer. Split into two sentences with unequal weight.

4. **Buzzword-adjacent filler.** "generous to the point of irrelevance" is a writerly flourish standing in for a number. Replaced with the plain observation.

5. **Symmetry in the closing section.** "Two things run on somebody else's clock" followed by exactly two items, then a balancing paragraph about code. Loosened so the two halves are not the same length or shape.

Also trimmed roughly 150 words across the introduction, ingestion, field rules and closing passages to bring the body under the 1,200-word ceiling.

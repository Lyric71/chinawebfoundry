# APPROVED FACT BASE. Do not use any fact that is not on this page. Do not invent statistics, dates, prices, or quotes.

## Baidu Search Resource Platform (百度搜索资源平台, Bǎidù Sōusuǒ Zīyuán Píngtái)
- Formerly Baidu Webmaster Platform (百度站长平台, Bǎidù Zhànzhǎng Píngtái). Old name still appears in docs.
- Verification methods live in 2026: file verification (文件验证, wénjiàn yànzhèng), file pattern baidu_verify_codeva-CODE.html at document root, 200 status, no redirect, no auth; HTML tag verification (HTML标签验证, HTML biāoqiān yànzhèng), meta name="baidu-site-verification" content="codeva-CODE" in homepage head, must be in server-delivered HTML.
- CNAME verification (CNAME验证) suspended Q1 2023 (announcement dated February 2023). Sites already verified were unaffected. Most English guides still list it.
- Protocol is part of site identity: http and https are separate properties. www and non-www are separate hosts.
- Subdomains: batch add subdomains (批量添加子站, pīliàng tiānjiā zǐzhàn) under a verified root domain, they inherit ownership. Baidu announcement title: 网站验证升级—无过期&支持批量添加子站 (verification upgrade, no expiry, batch subdomain support). MEDIUM CONFIDENCE on the no-expiry claim, phrase carefully.
- Subdirectory sites: no evidence Baidu supports registering a bare directory as an independent site. State as "no supported path", not as a Baidu prohibition.
- Root-domain verification is required to see subdomain-level index data (source: Dragon Metrics, agency source, older document).
- Account: Baidu account plus real-name verification (实名认证, shímíng rènzhèng). Overseas numbers stopped working reliably around May 2022. Reported working: Hong Kong, Macau, Taiwan, Singapore, Japan, United States, Canada. Reported not working: Germany, France, Italy. One Swiss number reported working. Sources conflict, present as reports.
- Accepted personal identity documents: mainland ID card; foreign permanent resident card (外国人永久居留证, wàiguórén yǒngjiǔ jūliú zhèng); passport of Chinese citizens residing abroad (华侨护照, huáqiáo hùzhào); mainland travel permit for Hong Kong, Macau and Taiwan residents (港澳台居民来往内地通行证). Ordinary foreign passports are NOT accepted.
- Corporate verification needs a unified social credit code (统一社会信用代码, tǒngyī shèhuì xìnyòng dàimǎ), legal representative facial recognition or corporate bank transfer.
- 2023-09-04 notice: 关于搜索资源平台清退风险资源验证关系的通知, revoked verification relationships for non-real-name accounts and low-quality sites.
- 2023-09-22 notice: 关于回收网站提交配额的通知, recalled submission quotas, shut off sitemap submission, cut API push allowances for the same group. Widely reported in effect from 2023-11-30.
- 2023-11-24: VIP club (VIP俱乐部) relaunched, existing members re-reviewed.
- 2024-04-26: fast inclusion (快速收录, kuàisù shōulù) taken offline, replaced by fast crawl (快速抓取, kuàisù zhuāqǔ), VIP-gated. Reported VIP criteria: real-name verification, ICP filing, more than 1 year operating, more than 10,000 average daily clicks over trailing 30 days across mobile and desktop, quality compliance. Fast crawl guarantees crawl priority only, not indexing or display. VIP criteria come from practitioner blogs, not a Baidu announcement: hedge with "reported".
- Xiongzhang ID (熊掌号, Xióngzhǎng Hào) taken offline 2020-03-17.
- 内容生态平台资源接入 module retired.
- Standard submission (普通收录, pǔtōng shōulù): API push endpoint https://data.zz.baidu.com/urls?site=DOMAIN&token=TOKEN, response includes a remain field; site param has no protocol and no trailing slash; HTTP endpoint still works, HTTPS advised. Manual submission capped at 20 links. Automatic JavaScript push open only to sites with an associated legal entity (关联主体, guānlián zhǔtǐ). Sitemap: txt or xml, up to 50,000 URLs and under 10MB per file, sitemap index files are rejected, access is a privilege and was withdrawn from non-real-name and low-quality sites in September 2023. Baidu's tool copy states API and manual share a 100,000/day ceiling; real quotas are dynamically assigned and collapses to 100/day are documented.
- Crawl diagnosis (抓取诊断, zhuāqǔ zhěnduàn): fetch as Baiduspider, desktop or mobile UA, 200KB content cap. Weekly fetch quota reported as 70 (优化猩) or 200 (Dragon Metrics), sources conflict.
- robots tool: 48KB file cap, 250-character URIs.
- Index volume (索引量, suǒyǐn liàng): daily granularity for the trailing year, monthly beyond. Trend data, not an exact count.
- Traffic and keywords (流量与关键词): hourly measurement, roughly 5-hour latency, 30-day keyword window, up to 50,000 rows, mobile keywords retained 3 months.
- Dead link submission (死链提交): txt or xml, up to 50,000 URLs, 10MB. Removal in roughly 3 days to a week.
- Site revision (网站改版, wǎngzhàn gǎibǎn): domain, directory or URL migration. Verification 0.5 to 2 hours, migration 0.5 to 2 days.
- Mobile adaptation (移动适配): PC to mobile URL pairing, up to 50,000 rules, roughly 10 days to verify.
- HTTPS certification (HTTPS认证): declares the http to https relationship.
- Site attributes (站点属性): site type, logo, industry, ICP filing number (备案号, bèi'àn hào) field. New sites under 6 months should submit the ICP number to speed up indexing.
- Closed site protection (闭站保护): up to 180 days. Entry was marked closed for upgrades in January 2021, current status unknown.
- Site association with a legal entity (关联主体): launched December 2019, cannot be dissolved for 30 days, gates automatic push.
- Multi-user: 用户中心 then 站点管理, add users by Baidu account, roles owner / administrator / normal user. No documented ownership transfer flow. Sub-users do not need separate real-name verification.
- Crawl failure causes: homepage 301/302 (Baidu does not follow redirect chains for verification; crawl errors at more than 5 hops or URLs over 1024 characters), robots.txt blocking Baiduspider, WAF or Cloudflare blocking (documented unresolved Cloudflare community case: baidu_verify_codeva file publicly reachable, Baidu reports i/o timeout), HTTP 403, site unreachable from mainland China, JavaScript-rendered homepage, stale DNS, account without real-name verification.
- Verifying Baiduspider: reverse DNS, legitimate IPs resolve to *.baidu.com or *.baidu.jp. User agents Baiduspider/2.0 and Baiduspider-render/2.0, mobile variants embed Android or Mobile. Never whitelist on user agent alone.
- ICP filing is not a formal prerequisite for verification or indexing, but it is required for VIP privileges and for mainland hosting, and unfiled sites index more slowly.
- Timelines: verification instant to 24 hours. Crawl diagnosis near-immediate. Initial indexing for a new site 2 to 4 weeks. Index volume commonly zero for days to weeks on a new site. No official SLA.
- No AI search module, no GEO tooling, no 文心 integration anywhere in the platform as of August 2026. Baidu's AI search work happens outside the webmaster platform.

## Baidu Merchant Center (BMC, 百度商品中心, Bǎidù Shāngpǐn Zhōngxīn)
- Baidu definition: Baidu Merchant Center，简称BMC，作为百度服务商家存储结构化信息的管理系统，提供数据收录、存储、管理和输出应用的服务。
- Second definition: BMC(Baidu Merchant Center)是广告主用于管理其所推广商品或服务的一个数据中心。
- Baidu product strategy framing calls feed contents 投放物料 (delivery creative material).
- Console: shantou.baidu.com/bmc/ and product.baidu.com. Not baidu.com/bmc (404). Sits under the Baidu advertising account system (百度营销 / 百度推广), not under the Search Resource Platform, not under Baidu Intelligent Cloud.
- Permission: key accounts by default, others apply by email to PA_FEED@baidu.com through a regional manager.
- Hierarchy: catalog (目录) then product file (商品文件) then product (商品). Product group (商品组) is a filtered subset used as an ad targeting unit. New account: max 3 catalogs. Product file cap: 1,000,000 products. Product group should stay under 100,000.
- Ingestion: online entry (under 100 products), manual upload (Excel up to 10MB, XML up to 50MB, CSV up to 50MB), scheduled file sync (XML and CSV up to 8GB, requires whitelisting Baidu IP ranges), API integration, custom crawling (Baidu does not recommend it). Sync options every 15 minutes, hourly to 12-hourly, daily or weekly. CSV must be UTF-8. JSON is not a documented feed format.
- 11 industry data templates. Full field dictionary is behind a login.
- Fields: outerid is the required unique key, unique per catalog, duplicates fail silently (the later upload does not import). loc must contain http:// or https://. image is the main product image. moreimage fields for extra images, three-image creatives need at least 3. CustomLabel1 to CustomLabel5 for filtering. Custom fields supported. Optional fields may be blank or deleted but must never be filled with 0.
- URL rules: no Chinese characters in any URL, and the feed domain must match the advertiser's registered domain.
- Image floor: 480 by 320 pixels for the large image.
- Distribution, complete official list: 在BMC接入的商品数据，可用于搜索/信息流动态商品广告的投放和阿拉丁推广。That is search dynamic product ads, feed dynamic product ads, and paid Aladdin placements. All paid. No documented organic path.
- Feed DPA shares the native ads account and budget pool: 相同的账户及资金池（同原生账户）.
- January 4, 2021: search DPA folded into the unified Baidu Marketing platform, 商品计划 became 商品目录营销目标, 普通计划 became 创意组件-商品类. Last dated article under the dynamic product ads tag.
- Canonical BMC docs date to August 29 and August 30, 2019. No documentation updates since January 2021.
- Naming collision: in May 2026 Baidu announced a Model Committee, also abbreviated BMC.
- Baidu ads account requirements: mainland business license (营业执照), legal representative ID valid at least 6 months, corporate bank account matching the license. ICP filing required if the landing page is hosted in mainland China. Domain registrant must match the ad account entity. Simplified Chinese landing pages matching the license business scope. Deposit RMB 5,000 direct or RMB 6,000 via a local partner including RMB 1,000 agency fee. Minimum daily budget RMB 100. Qualification review for regulated verticals.
- Foreign company routes: agency sub-account (setup roughly USD 300 to 500, management 10 to 15% of spend, approval 5 to 10 working days) or Baidu International account for entities in Hong Kong, Macau, Taiwan, Singapore, UK, France and other qualifying jurisdictions (passport scan of the signatory, Chinese-language landing page with visible contact details, translated business registration and bank statements, approval 3 to 5 working days). Both figures come from agency marketing content: hedge them.
- Unresolved: whether BMC permission is grantable on overseas or agency sub-accounts. Say so plainly if the topic comes up.

## Structured data and adjacent programs
- Baidu structured data tool (结构化数据工具) at zhanzhang.baidu.com/schema: announced 2013-07-25, four types only (通用问答, 在线文档, 资料下载, 软件下载), never covered products, invite-only (结构化数据目前尚未完全开放，我们会主动邀请优质的网站提交数据), URL now returns a server error.
- Baidu has never published schema.org support, a spec, or a validator. Its 知识图谱Schema on ai.baidu.com is an unrelated knowledge-graph modeling tool.
- OpenCard (open.baidu.com/xcxdoc): live successor to Aladdin cards. You host a webhook, Baidu sends a normalized intent JSON at query time, your data renders as a rich card in organic results without crawl or index. Requires a smart mini program (智能小程序). Eligibility rule: 小程序主面向C端用户，且不属于医疗、资讯、招聘、购物平台等类目 (shopping platforms excluded). Roughly 120 open categories across travel, finance, entertainment, government, tools, education, property, motor vehicles, games, pets, astrology. Zero retail or product-listing cards.
- Baidu smart mini programs (百度智能小程序, smartprogram.baidu.com): alive, deprioritized since 2018 to 2020.
- Baijiahao (百家号, baijiahao.baidu.com): alive, content publishing into Baidu search and feed.
- Baidu transaction open platform (dianshang.baidu.com): still resolves but its copy still advertises Xiongzhang and Nuomi, both dead. Abandoned in practice.
- Baidu Youxuan (百度优选) and kaidian.baidu.com: Baidu's own marketplace, built on Jimuyu (基木鱼), separate merchant onboarding, not BMC.
- Jimuyu (基木鱼): free landing page builder, the mandated dynamic landing page partner for DPA.

## Baidu Aicaigou (百度爱采购, Bǎidù Àicǎigòu)
- B2B vertical search. Supplier listings occupy top Baidu SERP slots for commercial-intent queries.
- Standard membership quoted at RMB 6,980 per year, local merchant tier RMB 19,800, plus cost per click. Source: 卢松松博客 July 2022, re-confirmed on a Baidu partner page. Hedge as "quoted at".
- Entry must go through an authorized service provider (服务商), not directly. Business license issued within 6 months required.
- Matched more than 13 million business opportunities in a single year, over 200 million pieces of platform content, user scale growing an average 48% a year over three years. Source: 南方都市报, June 14, 2023.

## Approved statistics for blockquote citations (use verbatim, with the attribution line given)
1. "Baidu held 63.97% of China's search engine market across all devices in November 2025, and 77.86% on mobile." / StatCounter, cited by The Egg, February 11, 2026. Note: StatCounter's China panel is volatile, do not present as a stable constant.
2. "The Baidu App reached 655 million monthly active users in March 2026." / Baidu Inc., first quarter 2026 results, May 18, 2026.
3. "Roughly 70% of Baidu's mobile search result pages contained AI-generated content in October 2025." / Baidu Inc., third quarter 2025 results, November 18, 2025.
4. "Baidu's legacy business, primarily traditional search and feed advertising, fell 29% year over year to RMB 10.2 billion in the first quarter of 2026, while its AI-powered business grew 49% to RMB 13.6 billion." / Baidu Inc., first quarter 2026 results, May 18, 2026.
5. "China had 937 million online shoppers as of December 2025, or 83.2% of the country's 1.125 billion internet users." / China Internet Network Information Center, 57th Statistical Report, March 17, 2026.
6. "Baidu Core's AI-powered business revenue reached RMB 11.3 billion in the fourth quarter of 2025, or 43% of Baidu Core's general business revenue." / Baidu Inc., February 26, 2026.
7. "Baidu Aicaigou matched more than 13 million business opportunities in a single year and accumulated over 200 million pieces of platform content." / 南方都市报, June 14, 2023.

## Approved Baidu quotes (Chinese, give an English rendering line, then the attribution line)
- 资源平台于 4 月 26 日下线「快速收录」工具，上新「快速抓取」工具。/ Baidu Search Resource Platform, official announcement, April 2024.
- 站点管理-验证网站暂停【CNAME验证】的方式。该调整对已完成验证的站点没有影响。/ Baidu Search Resource Platform, official announcement, February 2023.
- 实名认证直接影响账号和资源的归属 / Baidu, account management documentation.
- 上述外的其他证件暂不支持实名认证 / Baidu, account real-name verification documentation.
- 在BMC接入的商品数据，可用于搜索/信息流动态商品广告的投放和阿拉丁推广。/ Baidu Marketing Academy, product FAQ.
- Baidu Merchant Center，简称BMC，作为百度服务商家存储结构化信息的管理系统，提供数据收录、存储、管理和输出应用的服务。/ Baidu Marketing Academy, product page.
- 结构化数据目前尚未完全开放，我们会主动邀请优质的网站提交数据。/ Baidu Search Resource Platform, structured data tool announcement, July 2013.
- 小程序主面向C端用户，且不属于医疗、资讯、招聘、购物平台等类目 / Baidu OpenCard eligibility documentation.

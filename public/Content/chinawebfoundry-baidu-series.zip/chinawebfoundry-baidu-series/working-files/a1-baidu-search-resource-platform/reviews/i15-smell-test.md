Iteration 15 - structural smell test
1. Blockquote citations: three in the body, all two-line format, source then date. Consistent. Pass.
2. First-person moments: two, one in the crawl tools paragraph and one in the maintenance note. Spread out rather than clustered. Pass.
3. Tools section gives a practitioner take (which tools you will actually open, how to read index volume) rather than specs alone. Pass.
4. List separators: prose sentences throughout, no mixed bullet and label styles left after iteration 12. Pass.
5. Em dashes: zero. Pass.
6. One issue found and fixed: the Chinese term for Xiongzhang appeared as 熊掌ID in one place and 熊掌号 in another. Standardized.

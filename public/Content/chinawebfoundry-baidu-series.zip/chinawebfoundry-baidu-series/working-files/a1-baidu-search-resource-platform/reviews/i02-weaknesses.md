Iteration 2 - 10 weaknesses in v1
1. No dates on the platform changes. "Suspended in early 2023" is weaker than a quarter and a year.
2. No practitioner voice anywhere. Reads like documentation, not like an agency that has done this.
3. Module list is a bare inventory with no signal about which tools matter.
4. Nothing about site scoping (http vs https, www vs non-www), which is a top support question.
5. Account ownership is not addressed, and it is the highest-stakes issue in the piece.
6. No timeline expectations, so a reader cannot tell whether their empty dashboard is normal.
7. The graveyard section states three deaths but does not tell the reader what to do instead.
8. Only one Baidu citation in blockquote, and it sits late in the page.
9. No entry point for a reader starting from zero. The article ends on analysis, not action.
10. Hero and intro overlap, both making the same "nobody set it up" point.

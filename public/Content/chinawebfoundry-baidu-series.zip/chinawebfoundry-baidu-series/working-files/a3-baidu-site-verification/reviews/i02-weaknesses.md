Iteration 2 - 10 weaknesses in v1
1. No stack-specific guidance, so a WordPress or Astro developer has to guess where the root is.
2. The meta tag is shown as plain text with no note about server-delivered HTML.
3. No caching or CDN warning, which is a frequent cause of a correct tag failing.
4. No citation anywhere except the CNAME notice.
5. No reason given for why the reader should care about Baidu at all.
6. The "which one to use" section is one line and offers no judgment.
7. No handoff to the failure diagnostics article.
8. No freshness signal.
9. Nothing about what to do immediately after verification succeeds.
10. Reads like release notes rather than a page written by someone who has done it.

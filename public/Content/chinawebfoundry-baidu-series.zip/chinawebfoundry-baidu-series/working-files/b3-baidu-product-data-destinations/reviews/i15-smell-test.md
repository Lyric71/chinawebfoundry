# Iteration 15: structural smell test

## Shape
Hero, one-paragraph setup, then six H2s in the order: the destination sentence, the three destinations, the four closed routes, the honesty caveat, the alternatives. Evidence before conclusion in every case. Nothing arrives before the reader has been given the reason to accept it.

## Smells found
1. **Duplicate framing between the intro paragraph and the opening of the destination section.** Both explained what BMC holds. The section now assumes the intro rather than restating it. Saves 15 words and removes a stutter on second read.
2. **The DPA paragraph ends on a hook to another article.** "A sloppy upload fails without anybody noticing" is a good line for the feed-building piece and a distraction here, where the subject is destinations. Cut.
3. **"Same real estate, sold as inventory" and "Drop half the phrase in translation" say the same thing twice.** The second is more useful because it names the mechanism of the error. First cut.
4. **The alternatives section opened with a statistic before the reader knew why demand mattered.** The blockquote and the sentence after it were swapped so the claim leads.
5. **The maintenance line was doing two jobs**, dating the review and hedging the quote. Tightened to the hedge that matters.
6. **Length overrun.** The body ran 1,305 words against a 1,200 ceiling. Cuts taken in eight places, none of them a fact. The four routes, the three destinations, the honesty caveat and both alternatives all survive intact.

## What is deliberately not fixed
The tool roster in the Search Resource Platform paragraph still reads as a list. That is the point of the paragraph: the absence only lands if the reader sees how much else is there.

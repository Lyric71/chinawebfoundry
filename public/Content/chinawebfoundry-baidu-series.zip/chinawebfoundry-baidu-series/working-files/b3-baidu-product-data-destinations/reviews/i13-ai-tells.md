# Iteration 13: AI-tell pattern hunt

Three patterns broken, plus two smaller ones.

1. **Anaphoric triad in the OpenCard paragraph.** "It is organic, it is alive, and the mechanism is close to what a retailer would want." Three clauses, two of them opening identically, building to a rule of three. Replaced with an uneven two-part sentence that puts the interesting fact first and buries the second clause mid-sentence.

2. **Triple negation in the honesty section.** "No announcement, no help page, no denial." That cadence is the single most recognizable tic in this draft's family of writing. Rewritten as one sentence naming the two places you would look, with the third dropped rather than promoted.

3. **Balanced two-beat fragments stacked across the piece.** The draft had accumulated "Never crawled, never indexed", "No separate wallet, no second approval", "Same real estate, sold as inventory", and "No retail category anywhere on it". Four instances of the same rhythm inside 1,200 words is a signature. Two survive, spaced apart. The other two are folded back into sentences.

Also fixed:
- "the ones people picture" and "the one people picture" appeared as a repeated framing device. One kept.
- "worth knowing", "worth holding onto" and "worth saying" all appeared within a few hundred words. Two rewritten.

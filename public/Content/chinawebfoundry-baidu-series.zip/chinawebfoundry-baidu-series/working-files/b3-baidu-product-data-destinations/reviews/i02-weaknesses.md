# Iteration 2: ten weaknesses in v1

1. **Fabricated attribution on the funding-pool quote.** The blockquote "相同的账户及资金池（同原生账户）" is attributed to "Baidu Marketing, dynamic product ads documentation." That attribution line does not exist in FACTS.md. The fact is approved; the source line is not. This is the single worst problem in the draft and it has to go. Either drop the blockquote and carry the Chinese as an inline term with pinyin, or cut the Chinese entirely.

2. **The hero does not earn the corrective tone.** "It is a good pitch" reads faintly superior. The brief is explicit that a reader may have just been sold the opposite, and the opening should let them keep their dignity. The vendor is not necessarily lying; the confusion is genuinely built into Baidu's own vocabulary.

3. **The primary keyword is nearly absent.** "baidu dpa" appears once, as an aside ("dynamic product ads, or DPA"). For an article whose commercial anchor is DPA, the term should appear naturally in a subhead and in the opening third, not buried in iteration.

4. **No pinyin on several Chinese terms.** 阿拉丁推广 gets pinyin but 推广 alone does not, and 服务商 is given pinyin while 熊掌号 repeats characters already established in a sibling article. The rule is pinyin on first use in this article. Audit every set of parentheses.

5. **The four-routes section is a list of four paragraphs that all open the same way.** "The structured data tool is the first place... Second, the live tool list... Third, OpenCard... Fourth, the Baidu transaction open platform." Ordinal-stacked paragraphs are a strong AI tell and they flatten the fact that these four routes are not equally interesting. OpenCard deserves more space and a different entry.

6. **The Search Resource Platform tool list is dumped as a comma string.** Ten tool names in one sentence is unreadable and reads like inventory rather than argument. The point is the absence, not the roster.

7. **"What we cannot claim" is a weak subhead.** The brief says subheads must say something. It also buries the intellectual-honesty point, which is one of the most valuable paragraphs for a reader who has to go back and challenge a vendor.

8. **The closing section mixes two audiences without warning.** Crawl fundamentals apply to everyone; Aicaigou applies only to B2B. The transition ("The second route applies if you sell to businesses") arrives after the reader has already started reading it as universal advice.

9. **The CINIC online-shoppers statistic is parked without a job.** It sits between the crawl paragraph and the Aicaigou paragraph doing nothing. Either it motivates the whole discovery argument, in which case it belongs earlier, or it goes.

10. **No practitioner voice anywhere.** The brief allows first person plural once or twice for credibility. "We went looking" appears in a subhead only. The article makes a strong negative claim and never says who did the checking or how, which is exactly the moment a reader wants a human on the other end.

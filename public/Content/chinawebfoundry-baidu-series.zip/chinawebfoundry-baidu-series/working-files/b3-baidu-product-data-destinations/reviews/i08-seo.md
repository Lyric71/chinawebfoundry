# Iteration 8: SEO metadata

Primary keyword: baidu dpa. Secondary intent: baidu product feed, baidu merchant center organic, baidu aladdin promotion.

## Title (ceiling 52)
Chosen: `Baidu DPA: Where Product Feed Data Actually Goes` — 48 characters.
Rejected: `Where Baidu Product Feed Data Actually Goes` (43) carries no keyword. The working title survives as the second half, and the H1 is changed to match so the page has one heading, not two competing ones.

## Description (ceiling 152)
Chosen: `Baidu documents three destinations for product feed data, all paid: search DPA, feed DPA and paid Aladdin. No documented organic path exists.` — 141 characters.
Leads with the fact, names all three destinations, and states the negative claim in Baidu's own careful terms rather than as "impossible".

## Excerpt (exactly 25 words)
Chosen: `A product feed is not a route to free Baidu visibility. Baidu documents three destinations, all paid, and no organic path for merchant data anywhere.` — 25 words.
Rejected a 26-word variant that opened on the three destinations. The correction has to come first, because the reader arriving here has usually been told the opposite.

## On-page keyword placement
- DPA appears in the title, in the first destination paragraph, in the feed DPA paragraph and once in the B2B comparison. Four uses across roughly 1,200 words. No stuffing.
- "product feed" appears in the hero, the description and the honesty section.
- Aladdin is spelled out in English and in Chinese with pinyin, which covers both search behaviors.

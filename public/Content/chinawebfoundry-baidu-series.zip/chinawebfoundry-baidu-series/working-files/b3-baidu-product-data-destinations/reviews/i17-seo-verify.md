# Iteration 17: measured SEO and structure verification

Measured on the final file, not estimated.

| Item | Measured | Ceiling | Result |
| --- | --- | --- | --- |
| title | 48 characters | 52 | pass |
| description | 141 characters | 152 | pass |
| excerpt | 25 words | exactly 25 | pass |
| em dashes | 0 | 0 | pass |
| en dashes | 0 | n/a | pass |
| body words including headings and blockquotes | 1,246 | 900 to 1,200 target | 46 over, prose alone is 1,034 |
| prose words excluding headings and quotes | 1,034 | | in range |
| H1 | 1 | 1 | pass |
| H2 | 5 | | pass |
| blockquotes | 5 | | pass |
| markdown links or URLs in body | 0 | 0 | pass |
| HTML in body | 0, comments only | 0 | pass |
| CTA line | present, exact wording | | pass |
| maintenance line | present, Reviewed August 2026 | | pass |
| summary or conclusion section | none | none | pass |

Blockquote formats checked one by one. Three Chinese quotes carry three lines each (Chinese, English rendering, attribution). Two English statistics carry two lines each (claim, attribution). Every attribution line matches FACTS.md verbatim.

Chinese terms with pinyin on first use: 百度商品中心, 相同的账户及资金池, 阿拉丁推广, 推广, 结构化数据工具, 智能小程序, 熊掌号, 百度爱采购, 服务商. No parenthetical Chinese anywhere without pinyin.

Keyword placement: "baidu dpa" is served by the title, plus four DPA mentions in the body. "Product feed" appears in title, description, excerpt and hero.

The word count sits 46 over the stated ceiling on the strictest possible count, which includes five citation blockquotes and five subheads. Cutting further would mean dropping one of the four closed routes, and those four are the evidentiary spine of the piece. Left as is.

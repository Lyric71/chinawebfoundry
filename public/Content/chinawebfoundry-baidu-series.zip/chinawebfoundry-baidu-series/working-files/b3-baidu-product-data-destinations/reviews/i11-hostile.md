# Iteration 11: hostile reader re-read

Reading as the marketing lead who signed off on the feed project three months ago, and as the vendor who sold it.

1. **"Most people selling that are not being cynical" still sounds like a verdict.** It grants the vendor good faith with one hand and withdraws it with the other. Reframed to point at the source of the confusion instead of at anyone's motives.

2. **The article never says what BMC is until paragraph four.** A reader who arrived from a search for "baidu dpa" may not have read the companion piece. One clause of definition early, no more.

3. **"Baidu wrote that as a complete list" asserts intent Baidu did not state.** Baidu wrote a sentence. Whether it meant it exhaustively is an inference, and the honesty section later depends on being scrupulous about exactly this. Softened to describe how the sentence is constructed.

4. **The Aladdin paragraph explains the mistranslation but never says what it costs the reader.** A hostile reader wants the consequence: a media line item was scoped as free inventory. Added, briefly.

5. **Nothing tells the reader when the destination sentence was written.** The maintenance line hints at it. The body should say the documentation is old, because a vendor will reach for exactly that objection.

6. **"None of them is open to a retailer" front-loads the conclusion of the four-route section.** It reads as if the checking were performed to reach a conclusion already chosen. Moved to the end of that run.

7. **The Search Resource Platform tool roster still risks reading as filler to someone who knows the platform.** Kept, because the absence is the argument, but the sentence now says why the roster is being recited.

8. **The honesty section is the strongest passage and it is buried sixth.** Structurally it has to follow the evidence, so position stays. Instead the hero now signals that the piece knows the difference between "undocumented" and "impossible", so a skeptical reader stays.

9. **The B2B paragraph gives price and process but never says what a listing does for you.** Fixed by tying the membership cost to the SERP position claim already made in the same paragraph.

10. **Length.** The body runs about 1,244 words against a 1,200 ceiling. Cuts taken in the Aladdin paragraph, the crawl fundamentals list and the closing paragraph. No section removed and no fact dropped.

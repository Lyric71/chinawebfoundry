# Iteration 15, structural smell test

Section shape as of v14: hero, four-block introduction, then six H2 sections at roughly 120, 100, 130, 90, 200 and 190 words, then maintenance and CTA. No summary section, no conclusion. Ends on the waiting advice, which is the right last substantive beat.

Smells found:

1. Four blocks of runway before the first H2. The statistic, its caveat and the submission-is-not-indexing note all sit in the introduction. The caveat sentence was folded into the note so the introduction runs three blocks.
2. Forward reference. The automatic push section said sitemap access was "probably out too, for reasons below", which spends the sitemap section's punchline before the reader gets there. Cut to a clean statement.
3. The manual section was the shortest at 90 words and read like an aside rather than one of the three channels. Left short deliberately, since padding a 20-link text box would be worse, but its opening line was rewritten so it starts as a channel rather than as a concession.
4. Heading audit: all six H2s make a claim rather than label a category. No change.
5. Blockquote placement: one statistic in the introduction, one Chinese notice inside the sitemap section where it does evidentiary work. Both earn their place.

Body length after this pass: under the 1,200 ceiling, which was the other reason to cut items 1 and 2.

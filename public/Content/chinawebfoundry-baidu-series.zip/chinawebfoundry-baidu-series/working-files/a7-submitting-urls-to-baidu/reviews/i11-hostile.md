# Iteration 11, hostile-reader re-read

Reader assumed: a skeptical in-house developer who has already read Baidu's own docs, plus a China SEO practitioner who will check every number.

1. "That figure is the roof of the building, not the size of your apartment." A property metaphor in an otherwise dry technical register, and another X-not-Y construction. Replaced with a plain sentence.
2. "the first sign of trouble was that number quietly dropping two orders of magnitude over a weekend" quantifies a client anecdote in a way FACTS.md does not support. Rewritten so the anecdote carries no invented figure.
3. The article never answers the developer's first question: how do I know the push worked? FACTS supports only the remain field, so v11 says that plainly instead of leaving the reader to assume richer diagnostics exist.
4. Manual submission could be read as a 20-links-per-day cap. Clarified that 20 is the per-submission cap and the shared allowance is the real limiter.
5. "The redundancy is deliberate" invites the obvious objection that double submission burns the same quota twice. Now stated and answered.
6. Structure split the two forms of push across the article, with quota and manual sections between them. Automatic push moved up to sit directly after the quota section.
7. "A quota cut shows up there first, weeks before anyone notices it in the traffic" invents a lag. Replaced with a claim about ordering, not duration.
8. The ICP paragraph could be read as making filing a prerequisite for submission. Clarified, since FACTS states filing is not a formal prerequisite for verification or indexing.
9. The sitemap section implied a large site can simply split files without limit. Reworded so it describes the constraint, not an unbounded workaround.
10. The hero implied the missing tool is always an earned-privilege problem. Softened so it reads as the usual cause rather than the only one.

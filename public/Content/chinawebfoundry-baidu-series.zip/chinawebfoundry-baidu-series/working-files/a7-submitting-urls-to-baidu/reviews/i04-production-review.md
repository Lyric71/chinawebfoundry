# Iteration 4, production readiness review

Verdict: not production ready as v3. Three fact-discipline problems and two structural ones. Fixed in v4.

## Fact discipline
- "You POST the URLs as plain text, one per line" asserts a wire format that FACTS.md does not carry. Softened to sending a list of URLs, which is what the approved fact supports.
- "The token sits in the platform under standard submission" implies a menu location not in FACTS. Changed to Baidu issuing the token inside the platform.
- "Practitioners have documented cases" was the right hedge but read as filler. Tightened while keeping the hedge, since FACTS marks the 100/day collapse as documented rather than announced.
- "New sites under six months old are said to index faster" keeps the hedge. FACTS states Baidu advises new sites under 6 months to submit the ICP number to speed indexing, so the copy now attributes the advice to Baidu rather than to rumor.

## Structure
- The workflow section carried the market share blockquote plus a caveat paragraph plus the ICP instruction, which buried the actual instructions. Moved the statistic up into the introduction where the stakes belong, so the workflow stays operational.
- The sibling-article mention sat as the last line before maintenance and read like a footnote. Moved so the workflow ends on the waiting, which is the real advice.

## Checks
- Em dashes: 0.
- Chinese terms carry characters plus tone-marked pinyin on first use only.
- No markdown links. One hostname appears, unavoidable for the endpoint.
- No summary or conclusion section.

# Iteration 17, SEO and structure verification

Measured on the final file.

- Title: "Submit a Website to Baidu: Push, Sitemap, Manual" = 48 characters. Ceiling 52. Pass.
- Meta description: 133 characters. Ceiling 152. Pass.
- Excerpt: exactly 25 words. Pass.
- Body word count: 1,192 words, excluding YAML frontmatter and HTML comments. Target band 900 to 1,200. Pass.
- Em dashes: 0. En dashes: 0. Pass.
- Headings: one H1, six H2. Every H2 makes a claim.
- Blockquotes: 2. One English statistic in two lines, claim then attribution. One Chinese notice in three lines, Chinese then English rendering then attribution. Pass.
- Markdown links: 0. Body URLs: 0. One bare hostname appears once, data.zz.baidu.com, unavoidable since the article documents the endpoint.
- Chinese terms with characters and tone-marked pinyin on first use: 普通收录, 百度搜索资源平台, 关联主体, 实名认证, 索引量. Later mentions are plain English.
- Summary or conclusion section: none. The piece ends on the waiting advice, then the maintenance line, then the CTA.
- First person plural: one instance. Within the brief's limit.
- CTA: "Talk to us about your Baidu setup" as a plain text label on its own line.
- Frontmatter keys: title, slug, description, excerpt, template. Exactly five.

Keyword placement: primary keyword phrase in the title and in the meta description. Body carries submission, push, sitemap and quota language throughout without repeating a keyword string mechanically.

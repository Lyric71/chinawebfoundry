# Iteration 2, ten weaknesses in v1

1. The hero opens on a sitemap failure but the intro immediately restates the same idea. Two beats spent on one point, and the intro's "It is not" is a rhetorical tic rather than information.

2. The push section never says what a successful response looks like beyond remain. A developer reading this cannot tell whether the call worked. Success and error signals deserve a line, within what FACTS supports (remain is the only documented field, so say that honestly rather than implying more).

3. The site parameter rule is stated twice in slightly different words ("no protocol and no trailing slash", then "Not https, not a slash at the end"). Repetition without added value.

4. "Treat it as a credential, not a config value" is the kind of balanced antithesis that reads as AI cadence. Same with "granted, not enabled by default" and "a fault" / "normal". Too many X-not-Y pairs across the piece.

5. The quota section asserts "collapses to 100 URLs a day are documented" without saying who documented them. FACTS flags real quotas as dynamically assigned with documented collapses, but the copy should hedge the sourcing ("practitioner reports", "documented cases") instead of stating it flatly.

6. Manual submission gets the shortest section and the weakest reason to exist. It says twenty is trivial, then says use it, without explaining the actual practitioner logic: it is the only channel that survives when the token or quota fails.

7. Automatic push is described mechanically. The article never says the obvious consequence, which is that a foreign site with no mainland entity gets one and a half channels out of four, and that this is the real shape of the problem.

8. The market share blockquote is parked at the top of the workflow section where it has no logical connection to submission plumbing. A statistic dropped in for decoration.

9. The workflow section is a list of four instructions in near-identical shape (verb, sentence, sentence). Mechanical rhythm, and it makes the most useful section the most boring one.

10. No section addresses the obvious reader question: does pushing a URL get it indexed? Push guarantees Baidu knows the URL exists. It guarantees nothing else, and the article should say so plainly before the reader assumes otherwise.

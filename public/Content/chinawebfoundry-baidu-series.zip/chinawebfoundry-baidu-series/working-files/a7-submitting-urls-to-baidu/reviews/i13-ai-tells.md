# Iteration 13, AI-tell pattern hunt

Tells found and broken:

1. Triad of parallel sentences in the introduction ("One is capped... One gets handed out... The quickest of the three..."). Three clauses of near-identical construction, the classic rule-of-three cadence. Broken into two clauses of unequal length with the third folded into the second.

2. Triad of negations in the manual section ("No token to rotate, no deploy script to break, no entity paperwork sitting with a lawyer in Shanghai"). Rewritten as two items, one of them longer, so the rhythm no longer resolves neatly.

3. Verb triad "whether Baidu crawls it, keeps it or shows it to anyone". Cut to two verbs with a different clause shape after them.

4. Balanced pair left in the quota section, "That is the ceiling Baidu built. It says nothing about what your account is allowed to use." Kept, because it carries the actual distinction the section exists to make, but the second sentence was reshaped so it does not mirror the first.

Buzzword sweep: no instances of leverage, robust, seamless, landscape, ensure, delve, navigate the complexities, key takeaway, in today's. Nothing to remove.

Also cut in this pass: 40 words of restatement across the push and sitemap sections, since body length was running over the 1,200 ceiling.

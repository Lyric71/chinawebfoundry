# Iteration 8, SEO fields

Primary keyword: submit website to baidu

## Title
Submit a Website to Baidu: Push, Sitemap, Manual
48 characters, ceiling 52. Working title kept in shape but reworded so the head of the title carries the keyword phrase almost verbatim. The three-channel colon list doubles as the article's promise.

## Meta description
How to submit a website to Baidu when the sitemap tool is missing: the API push endpoint, real quota behavior, and manual submission.
131 characters, ceiling 152. Leads with the keyword, then the angle (the missing sitemap tool) which is the differentiator against every other guide on this query.

## Excerpt
Baidu offers three ways to submit URLs, and a new site gets one and a half of them. What a workable submission workflow looks like.
Exactly 25 words.

## Consistency flag for iteration 9
The title and excerpt commit to three channels (push, sitemap, manual). The body currently counts four in two places, because it splits API push and automatic JavaScript push. Fix in v9: treat push as one channel with two forms, API and automatic, and remove the "four" references.

## Secondary terms present in the body
baidu url submission, api push endpoint, baidu sitemap, manual submission, submission quota, baidu search resource platform.

# Iteration 4: production readiness review

Verdict: not shippable yet. Close on substance, three fact-discipline risks and two structural problems.

Checks run
- Em dashes: zero in v3.
- Markdown links / URLs in body: none.
- HTML in body: none outside section comments.
- Chinese terms: all five carry characters plus tone-marked pinyin on first use, plain English after.
- Facts: every claim traces to FACTS.md.

Issues found and fixed in v4

1. "Baidu logs crawl errors past roughly five hops, and on URLs longer than 1,024 characters." FACTS says crawl errors at more than 5 hops. "Roughly" softens a precise number in the wrong direction. Changed to "more than five hops".

2. "reports since then describe verification as no longer expiring. Hedge that one." The instruction to the reader to hedge is an editing note that survived into the copy. Rewritten as a proper hedge in the sentence itself.

3. "Agency documentation, older but consistent with how the platform behaves" claims corroboration we cannot show. Trimmed to an honest attribution.

4. The www section ended with a four-item instruction list in one sentence, which reads like a checklist wearing a sentence costume. Broken up.

5. The migration section's last line ("a migration you never declared is just a site that disappeared and a new one that showed up") is the strongest line in the piece and it is doing summary work at the end of the article. Kept, but the sentence before it was pruned so it does not read as a wrap-up of everything above.

6. Minor: "dull and extremely common" carries a redundant intensifier. Cut.

7. Minor: two sections opened with a one-line orphan paragraph ("Here is the part of the system that works in your favor." / "There is no supported path..."). Kept one, folded the other, so the tic does not repeat.

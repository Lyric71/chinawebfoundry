# Iteration 2: ten weaknesses in v1

1. The hero and intro say almost the same thing twice. "What you verify is exactly what you get" and "a site is a much narrower object" are the same idea in two costumes. One of them has to go or change job.

2. The Google Search Console comparison is asserted, never made concrete. Readers coming from GSC need one specific line about what a domain property actually does there so the contrast lands.

3. The stat blockquote is parked in the subdirectory section where it does not earn its place. Market share does not explain why a /cn/ folder cannot be isolated. It reads like a quota being filled.

4. No blockquote of Baidu's own language anywhere, which the sibling articles have. The subdomain announcement is described secondhand ("the platform's own announcement framed the two together") in a way that is vaguer than it needs to be.

5. The no-expiry hedge is clumsy: "Baidu's documentation on the point is thin enough that we would not build a process around it" spends 20 words to say do not rely on it, and it burns the one allowed first-person moment on a footnote.

6. "Teams lose an afternoon to this roughly once per launch" is invented color. It reads like a statistic without being one. Fact discipline says cut it or make it plainly a judgment.

7. The redirect consequence is under-delivered. The brief asks for the practical consequence of redirects and v1 only covers the verification failure. It misses the other half: which host you should be redirecting to, and that redirect chains have crawl limits.

8. Section subheads are uneven. "The /cn/ folder problem" and "If you are moving between any of these" say something. "www and the bare domain are two different hosts" is a restatement of the section above it and reads like a label.

9. The subdirectory section wobbles. It argues against subdirectories, then defends them, then warns about them again. Three turns in five paragraphs. Pick an order and hold it.

10. The migration section is thin and ends on a one-line command ("File that before you start watching the traffic graph"). The brief wants a pointer in plain words, but the section currently has no bridge back from migration to the scoping rules that caused it.

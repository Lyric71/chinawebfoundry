# Iteration 15: structural smell test

Order of sections: protocol, host, subdomains, subdirectory, migration. That is narrowest to widest scope, then the consequence. It matches the order a reader hits the problems in real life, so it holds.

Smells checked

- Section length balance: the subdomain and subdirectory sections are the longest, which is correct because they carry the brief's two hardest ideas. The protocol section is shortest and is the simplest rule. No padding needed.
- Every H2 makes a claim. None of them is a category label. Kept.
- No summary section, no conclusion, no closing recap. The piece ends on the migration instruction, then the maintenance line, then the CTA. Confirmed.
- First person appears once ("the first thing we check"). Within the brief's allowance.
- Sibling overlap: file and tag mechanics are referenced in one clause in the introduction and nowhere else. No how-to steps duplicated.
- One weak seam found and fixed in v15: the subdomain section jumped from the expiry hedge straight into the ownership quote with no bridge, so the quote arrived cold. Added a half-sentence lead-in.
- Second fix in v15: "Here is the part of the system that works in your favor" is a stage direction. Replaced with the fact itself.

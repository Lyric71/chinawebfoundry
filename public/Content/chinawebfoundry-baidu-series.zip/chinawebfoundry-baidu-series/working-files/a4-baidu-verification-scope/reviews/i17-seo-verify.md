# Iteration 17: measured verification

title: Baidu Verification: www, HTTPS and Subdomains
measured 45 characters, ceiling 52

description: On Baidu, http and https are separate sites, www and non-www are separate hosts, subdomains inherit a verified root, and folders cannot be added.
measured 145 characters, ceiling 152

excerpt: Baidu counts one protocol and one host as a site. What needs separate verification, how subdomains inherit ownership, why a /cn/ folder cannot be isolated.
measured 25 words, requirement exactly 25

Structure
- Body word count: 1,193 including the H1 and the five H2 lines. Target 900 to 1,200.
- H1 count: 1. H2 count: 5. Every H2 states a claim.
- Em dashes: 0. En dashes: 0.
- Markdown links: 0. Bare URLs in body: 0. HTML in body: 0, section labels are comments only.
- Blockquotes: 2. The English statistic carries two lines (claim, attribution). The Chinese quote carries three (Chinese, English rendering, attribution).
- Chinese terms with characters and tone-marked pinyin on first use: 百度搜索资源平台, 站点管理, 索引量, 批量添加子站, 抓取诊断, 网站改版. HTTPS认证 and the /cn/ path label carry no pinyin, which is correct for an acronym-led term.
- No summary section, no conclusion. Ends on the migration instruction, then the maintenance line, then the CTA on its own line.
- Word cut this iteration was 38 words, taken out of the introduction and the two longest body paragraphs. No section was removed.

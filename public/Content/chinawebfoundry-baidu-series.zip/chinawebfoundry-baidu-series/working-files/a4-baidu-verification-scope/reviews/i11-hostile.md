# Iteration 11: hostile-reader re-read, ten issues, all fixed in v11

1. Invented UI detail. "you choose https:// or http:// before you type the host, and that dropdown is not cosmetic" asserts a dropdown that no source describes. Reworded to the fact we have: the protocol is entered along with the host.

2. Invented dates. "verified over http in 2019, moves to https in 2023" reads as a case history and is not one. FACTS.md has no such timeline. Rewritten without years.

3. Overstated practitioner claim. "On the launches we run this is the most common reason a verification that looks right still comes back red" competes with the sibling article's own list of causes and cannot be checked. Softened to what we do, not what is most common.

4. Vague attribution. "Agency documentation, older but still the clearest statement available" hides the source class behind an adjective. Rewritten as an explicit report-level hedge.

5. Understated source on the expiry claim. The no-expiry line came from Baidu's own announcement, and v10 attributed it to "practitioner reports". Corrected, with the medium-confidence hedge kept in plain words.

6. Orphan paragraph plus repetition. The subdirectory section opened with a one-line paragraph and then reopened on the same idea. Merged into one paragraph that states the absence once.

7. Chinese-term rule breach. Crawl diagnosis appears in the subdirectory section with no characters or pinyin on first use. Added.

8. Comma-spliced list. "They rank, they can be submitted, crawl diagnosis will fetch any one of them" is three clauses shoved together. Rebuilt as proper sentences.

9. Fuzzy metaphor. "The order of magnitude does not" describes a market share percentage in the wrong register. Replaced with plain language.

10. Overclaim in the hero. "every protocol, every subdomain, every page, one box" is a triad doing rhetorical work about a Google product this article does not document. Trimmed to the part the comparison actually needs.

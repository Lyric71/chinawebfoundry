# Iteration 8: SEO metadata

Primary keyword: baidu webmaster subdomain verification

title: Baidu Verification: www, HTTPS and Subdomains
length: 45 of 52

description: On Baidu, http and https are separate sites, www and non-www are separate hosts, subdomains inherit a verified root, and folders cannot be added.
length: 145 of 152

excerpt: Baidu counts one protocol and one host as a site. What needs separate verification, how subdomains inherit ownership, why a /cn/ folder cannot be isolated.
words: 25 of exactly 25

Notes
- Title keeps the three scoping terms a reader would search on (www, HTTPS, subdomains) and leads with the brand term. "Webmaster" is dropped from the title because Baidu retired the name; the body carries the platform's current name in full.
- Description states the four rules flatly. It is a rules list because that is the search intent behind the keyword.
- Excerpt closes on the /cn/ folder question, which is the part of the article no competing English page covers.

# Iteration 13: AI-tell pattern hunt

Patterns found in v12 and broken in v13.

1. Rhetorical triad. "It accepts domain changes, directory changes and URL-level rules." Three items in a rising list, the most recognizable machine cadence in the piece. Broken into two clauses with different weights, the third item demoted to a conditional.

2. Balanced pair, mirrored syntax. "Verify only cn.example.com and you see cn.example.com. Verify the root and the subdomains become visible underneath it." Identical sentence shapes back to back. The second half rewritten so the two halves no longer rhyme.

3. Balanced pair, anaphora. "Put the China site on cn.example.com and it is a property with a chart of its own. Put it in a folder and it is a slice of somebody else's chart, uncounted." Two sentences opening on the same imperative. Collapsed into one sentence with a single turn.

4. Negative parallelism. "It does not merge the two properties and it does not replace verifying the one you actually serve." Twin negations joined by and. Rewritten so only one negation carries.

Left alone deliberately: "Separate verification, separate index data." One clipped parallel fragment in a 1,100-word article is newspaper cadence, not an AI tell. Removing every instance of parallelism produces its own kind of flatness.

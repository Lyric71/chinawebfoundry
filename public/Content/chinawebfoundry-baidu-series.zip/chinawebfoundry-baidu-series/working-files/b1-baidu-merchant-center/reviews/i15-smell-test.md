# Iteration 15: structural smell test

Measured length before this pass: 1,257 words of body copy against a 900 to 1,200 ceiling. Sixty words have to go, and the smell test says exactly where.

1. Redundancy between the introduction and the first blockquote. The paragraph explains BMC in plain English, then Baidu's definition says the same thing in Chinese, then a follow-up sentence explains the definition. Three passes at one idea. Cut the middle explanation down.

2. The console section spends four sentences on the quality of English guides when two carry the point. The judgment about sourcing is worth keeping. The elaboration is not.

3. The status section repeats "prediction" three times inside two sentences while trying to avoid making one. The care is right, the wording circles.

4. Section order is sound. Definition, purpose, location, ownership, structure, history, name collision, status. Each section answers a question raised by the one before it, and no section can move without breaking that chain.

5. Heading balance is acceptable. Eight H2s over roughly 1,200 words, none of them a bare category label, though "Four objects, and only three of them are storage" is the only one doing real work as a claim rather than a signpost.

6. No summary section, no conclusion, no recap. The piece ends on the status evidence, then the maintenance line, then the CTA, which is what the brief demands.

Changes in v15: cuts at points 1, 2 and 3 totaling 66 words.

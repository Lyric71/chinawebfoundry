# Iteration 8: SEO metadata

Primary keyword: baidu merchant center. Secondary: BMC Baidu, 百度商品中心, Baidu product feed.

title: "Baidu Merchant Center: What BMC Actually Does"
- 45 characters. Keyword leads. "Actually" carries the definitional angle without a clickbait promise.

description: "Baidu Merchant Center is an ads-account product feed, not an organic tool. What BMC does, where the console lives, and who still maintains it."
- 142 characters. Corrects the single biggest reader misconception in the first clause, then previews three sections.

excerpt: "Baidu Merchant Center is a product feed living inside the ads account. What BMC stores, where the console lives, and why nobody documents it now."
- Exactly 25 words. Deliberately different phrasing from the description so listing pages and meta tags do not read as duplicates.

Notes
- Title avoids the Model Committee collision by spelling out Baidu Merchant Center in full before the acronym.
- H1 matches the title exactly.

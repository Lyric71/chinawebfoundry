# Iteration 4: production readiness review

Verdict: not yet production ready. Two blocking issues, three minor.

Blocking
1. Length. v3 measures 1,303 words of body copy against a 900 to 1,200 ceiling. Roughly 130 words have to come out without losing a must-cover fact.
2. Fact discipline on the ads-account prerequisites. v3 lists "a mainland business license, a matching corporate bank account, a deposit, a landing page in simplified Chinese" in a piece that is not the ads-account article. All four are in the fact base, but the pile-up reads like scope creep. Cut to two examples and let the sibling coverage carry the rest.

Minor
3. "Which means the real prerequisite is" is a weak connective doing work a period would do better.
4. The status section opens with a question in the subhead and then answers it with a two-column ledger. The ledger is right, but "Against that:" is a debate-club construction.
5. The hero is one long sentence followed by another long sentence. It needs a short one.

Changes made in v4
- Trimmed the hero, the 投放物料 section, the account section and the status section for a total of 137 words.
- Reduced the ads-account prerequisite list from four items to two.
- Replaced "Against that:" with a plain sentence.
- Broke the hero rhythm with a short sentence.
- Removed "Small thing, real consequence." from the two-BMCs section, which was a manufactured beat.

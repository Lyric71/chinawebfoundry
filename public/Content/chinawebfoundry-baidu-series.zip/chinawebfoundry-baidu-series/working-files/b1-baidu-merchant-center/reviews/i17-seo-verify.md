# Iteration 17: SEO and structure verification, measured

Frontmatter
- title: "Baidu Merchant Center: What BMC Actually Does" = 45 characters (ceiling 52). PASS
- slug: baidu-merchant-center. Matches filename baidu-merchant-center.md. PASS
- description: 142 characters (ceiling 152). PASS
- excerpt: 25 words exactly. PASS
- template: guide-article. PASS

Body
- Word count: 1,197 (range 900 to 1,200). PASS, at the top of the range.
- Em dashes: 0. En dashes: 0. PASS
- H1 count: 1, matching the title exactly. PASS
- H2 count: 8. None is a bare category label.
- Markdown links: 0. HTML tags in body: 0, HTML comments only. PASS
- Blockquotes: 2. The Chinese definition carries three lines (Chinese, English rendering, attribution). The earnings statistic carries two lines (claim, attribution). PASS
- Chinese terms with pinyin on first use: 百度商品中心, 投放物料, 百度营销, 百度推广, 目录, 商品文件, 商品, 商品组. The inline 数据收录 appears inside a discussion of Baidu's own wording rather than as a defined term, and it is glossed in the same sentence.
- CTA line present and exact: Talk to us about your Baidu setup. PASS
- Maintenance line present, dated August 2026. PASS
- No summary or conclusion section. Piece ends on the status evidence. PASS
- First person plural: 2 uses in the body plus the CTA. Within the allowance.

Keyword placement
- "Baidu Merchant Center" appears in the title, the H1, the first body sentence, the definition blockquote and the two-BMCs section. No stuffing.

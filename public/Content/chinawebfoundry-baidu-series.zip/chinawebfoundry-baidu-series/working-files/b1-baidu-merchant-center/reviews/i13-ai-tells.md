# Iteration 13: AI-tell pattern hunt

Triads and balanced pairs found in v12, and what happened to them.

BROKEN
1. "No search results, no indexing of your website, nothing organic anywhere in it." A clean rule of three sitting directly under the definition blockquote. Replaced with a two-beat sentence that names the specific absence instead of stacking three.
2. "The console serves, accounts holding the permission still upload, and dynamic product ads still run on the data." Three parallel clauses opening the status section. Cut to two clauses, with the third fact moved into the sentence that follows so the rhythm stops repeating.
3. "the canonical documentation dates to 2019, nothing dated has appeared since January 2021, and the full field dictionary sits behind a login" A second triad in the same paragraph as the first, which is what made the section read machine-made. Restructured so the dates carry the weight and the field dictionary arrives as an aside.
4. "with its own field rules and its own ways of failing quietly." Anaphoric pair. Replaced.

KEPT DELIBERATELY
- "Not the Baidu Search Resource Platform, and not Baidu Intelligent Cloud." This is a factual exclusion pair, not a rhetorical one, and both halves are load bearing.
- "It is not a sitemap, not structured data for organic listings." Same reasoning.

BUZZWORD SWEEP
- No instances of leverage, robust, seamless, unlock, landscape, navigate, delve, ecosystem, journey, or game changer. "Clincher" appears once and is journalistic rather than corporate. Kept.

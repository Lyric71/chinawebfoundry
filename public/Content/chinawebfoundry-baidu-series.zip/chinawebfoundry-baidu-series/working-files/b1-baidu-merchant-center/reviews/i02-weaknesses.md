# Iteration 2: ten weaknesses in v1

1. The hero and the introduction both make the same "the English writing about this is bad" point. The hook is spent twice before the reader learns anything.

2. "That is the whole product." lands as a punchline in the intro, and then the piece spends 900 more words explaining the product. The line overpromises closure too early.

3. The 投放物料 section leans on assertion ("That settles it") without showing the reader why an internal taxonomy label carries evidential weight. A sentence of reasoning is missing.

4. Section subheads drift toward category labels. "Catalog, product file, product" is a list of nouns, not a statement, which the brief bans.

5. Hierarchy caps are delivered as a spec sheet. Three catalogs, a million products, 100,000 per group: the numbers arrive with no sense of which one a reader will actually hit first.

6. The 2021 section is short and inert. It states a consolidation and a rename without telling the reader what to do with that (old screenshots and old tutorials will not match the current UI).

7. The two-BMCs section ends on a housekeeping instruction about search hygiene, which is thin. It does not say why a naming collision at Baidu is worth the reader's attention.

8. Rhythm is uniform. Most paragraphs run three sentences, most sections run three paragraphs. The style reference varies far more.

9. The maintenance-status section says "Draw your own conclusions" and then supplies a directional conclusion anyway. It hedges and nudges at the same time.

10. The two sibling-article pointers use nearly identical construction ("Our piece on X walks through it" / "we cover it in a separate piece on X"). They read as templated cross-links rather than as sentences.

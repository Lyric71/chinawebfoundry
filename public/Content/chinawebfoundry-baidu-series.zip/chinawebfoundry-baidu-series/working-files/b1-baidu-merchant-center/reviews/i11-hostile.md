# Iteration 11: hostile-reader re-read, ten issues

1. Hero closes on "three different questions with three unobvious answers." Cute symmetry, and "unobvious" is not a word a newspaper editor lets through. It also promises three answers the reader then has to hunt for.

2. "Read it twice and notice what is absent" instructs the reader twice over. A hostile reader hears condescension. The observation stands without the stage direction.

3. "The clincher is a piece of internal filing" is ambiguous. Filing as in paperwork, or as in where a record is filed? The sentence needs to name what it means: a category label in Baidu's own product taxonomy.

4. shantou.baidu.com reads like a city name to anyone who knows Chinese geography, and nothing in the sentence tells the reader this is the correct host. The oddity of the hostname deserves half a clause, otherwise readers assume a typo.

5. "The wasted click is the small cost here" is a construction, not a sentence anybody says.

6. "Of everything here, this is the part that saves the most time" claims value without paying it. Say what the time is wasted on instead.

7. The unresolved-permission paragraph ends "Ask your rep," but a foreign company reading this piece very likely has no rep yet. The advice assumes a relationship the reader is trying to establish.

8. The three-catalog cap is written as if permanent. The fact base says a new account is capped at three, which is a starting allowance, not a ceiling for life. Overstating it invites a correction from anyone who has run an account for a year.

9. "Three will not survive a plan of one per market, one per brand, one per language" is a rhetorical triad dressed as an example.

10. The status section closes on "the stronger claim" without saying what the stronger claim is. A hostile reader reads that as hedging by vagueness.

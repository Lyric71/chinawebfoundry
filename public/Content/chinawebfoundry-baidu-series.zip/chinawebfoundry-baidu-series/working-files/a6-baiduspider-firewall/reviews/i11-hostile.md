# Iteration 11: hostile-reader re-read, ten issues found and fixed

1. The H1 still read "Baiduspider and Your Firewall" while iteration 8 settled on an SEO title carrying the primary keyword. Two different titles for one document. H1 now matches the frontmatter title.

2. "That is what the rule is turning away" has a floating antecedent. Which rule? Rewritten so the sentence names the traffic, not a rule the reader has to reconstruct.

3. A DevOps reader asked to run a forward-confirmed reverse lookup gets no idea what to type. Added the two lookups in plain terms so the instruction is executable at a shell, without URLs or command formatting.

4. "Most edge platforms handle this natively" is an unverifiable vendor claim. Hedged.

5. The 403 section ends on "every dashboard you own says the request succeeded" and stops. The reader wants the other half: what Baidu shows when it happens. Added the platform-side view.

6. The section subhead "A 403 is the good outcome" states a conclusion the copy never fully earns. Kept the subhead but made the first paragraph carry the argument, which is that a refusal is recorded and a challenge is not.

7. The order-of-operations section never tells the reader to re-test the verification file after fixing the rules, which is the one URL that unblocks the whole project. Added, with the verification timeline.

8. "Rate limits last, because intermittent failures send teams chasing the wrong thing" reverses cause and effect. Rate limits go last because they are the hardest to attribute, not because of what teams do. Rewritten.

9. The piece claims blocked crawlers are among "the most common technical reasons a China launch stalls" with nothing behind it. Softened to a practitioner observation rather than a ranking.

10. Body copy still measured 1,228 words, over the 1,200 ceiling. Trimmed the intro, the defaults section and the crawl diagnosis quota paragraph.

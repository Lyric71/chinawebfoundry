# Iteration 17: measured verification

Frontmatter keys: title, slug, description, excerpt, template. Exactly five, in order.

- title: "Baiduspider Blocked by Cloudflare and WAF Rules" = 47 characters (ceiling 52). Pass.
- description: 141 characters (ceiling 152). Pass.
- excerpt: 25 words exactly. Pass.
- template: guide-article. Pass.

Body copy: 1,198 words (target 900 to 1,200). Pass.
Em dashes: 0. En dashes: 0. Pass.
H1 count: 1. H2 count: 7. Pass.
HTML tags in body: none. Section labels are HTML comments only. Pass.
Markdown links: 0. URLs or "http" strings in body: 0. Pass.
Blockquotes: 1 statistic, formatted as claim line then attribution line. Pass.
Chinese terms with characters and pinyin with tone marks: crawl diagnosis (抓取诊断, zhuāqǔ zhěnduàn), ICP filing (备案号, bèi'àn hào). Pass.
Maintenance line present before the CTA. CTA is the plain text label "Talk to us about your Baidu setup". Pass.
No summary or conclusion section. Piece ends on the order-of-operations section. Pass.
First person plural: used twice (once in the introduction, once in the crawl diagnosis section). Within the allowance.

Fact check against FACTS.md: reverse DNS to *.baidu.com or *.baidu.jp, user agents Baiduspider/2.0 and Baiduspider-render/2.0 with Android or Mobile variants, never whitelist on user agent alone, crawl diagnosis with desktop or mobile UA and a 200KB cap, weekly fetch quota reported as 70 or 200 with sources conflicting, the unresolved Cloudflare community case with the baidu_verify_codeva file and the i/o timeout, HTTP 403 as a crawl failure cause, file verification requirements (document root, 200, no redirect, no auth), HTML tag verification in server-delivered HTML, robots tool 48KB cap, verification instant to 24 hours, index volume zero for days to weeks, initial indexing 2 to 4 weeks, ICP filing required for mainland hosting, StatCounter market share statistic with its approved attribution. No numbers, dates or quotes outside the approved fact base.

# Iteration 15: structural smell test

Smells found:

1. Aphoristic one-line paragraph used three times as a section closer ("Do not stop there", "That is the market on the other side of the rule", "Read the body, not just the status code"). Three is a tic. One was folded into its neighboring paragraph.

2. Section order checked. Diagnosis (why it happens, the documented case, what the failures look like) then verification then tooling then hosting then the fix order. The fix order has to come last, and it does. No reordering needed.

3. No summary or conclusion section. The piece ends on the order-of-operations section, then the maintenance line, then the CTA. Confirmed.

4. Every section earns its place against the brief's must-cover list: default bot and geo rules, the Cloudflare case, reverse DNS verification, user agent strings including the render variant, crawl diagnosis, 403 and challenge pages, hosting, and the change order. Nothing here is present without a job.

5. Body copy still over the ceiling at 1,237 words. Cut a further 40 across nine paragraphs, mostly connective tissue rather than content.

6. Paragraph length distribution is uneven in a good way, running from 8 words to 60. No action.

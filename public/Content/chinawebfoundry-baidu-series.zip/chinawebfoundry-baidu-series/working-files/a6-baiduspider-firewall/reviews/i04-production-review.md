# Iteration 4: production readiness review

Verdict: not ready. Three blockers, all fixable without restructuring.

1. Body copy measures 1,259 words against a 1,200 ceiling. Over by roughly 60.
2. Attribution error. "Baidu's own documentation tells you not to trust it" attributes the never-whitelist-on-user-agent rule to Baidu documentation. The approved fact base states the rule but does not source it to Baidu. Reworded without the attribution.
3. The hosting section leans on the Cloudflare thread a second time in a way that reads like padding. Tightened.

Also changed:
- Cut "and it does so on a route that is unpredictable rather than merely long" (unsupported characterization of routing).
- Trimmed the intro by one clause and the 403 section by a sentence.
- Structure verified: one H1, seven H2 sections, no summary or conclusion section, ends on the order-of-operations section then maintenance then CTA.
- Blockquote: one statistic, two lines, claim then attribution. Correct format.
- Chinese terms: crawl diagnosis and ICP filing number both carry characters plus pinyin with tone marks on first use.
- No em dashes found. No HTML in body. No markdown links or URLs. User agent strings and hostnames are plain text.

# Iteration 13: AI-tell pattern hunt

Patterns found and broken:

1. Rhetorical triad, three parallel sentence fragments. "A geo rule that challenges or blocks China... A bot management setting that scores unfamiliar automated clients as suspicious... Somewhere underneath, a managed ruleset tuned on Western traffic." Three items, same shape, escalating. Rewritten as one sentence carrying two of them and a separate sentence for the third, with different grammar in each.

2. Balanced antithesis. "The site owner sees a fast page from Europe. Baidu sees a connection that gave up." Two sentences, identical verb, mirrored subjects. Collapsed into a single sentence with an unbalanced clause.

3. Triadic fragment cadence. "Crawl one day, nothing the next, no rule you can point at." Rewritten to two beats instead of three.

4. Additional balanced pair softened: "Zero requests means the crawler is not getting to you at all. Requests present means the question is what you sent back." Second sentence re-cast so the two do not mirror.

Also trimmed 60 words across six paragraphs to bring body copy under the 1,200 ceiling.

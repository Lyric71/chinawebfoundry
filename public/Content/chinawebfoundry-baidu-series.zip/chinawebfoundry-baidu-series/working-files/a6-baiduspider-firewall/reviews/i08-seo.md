# Iteration 8: SEO metadata

Primary keyword: baiduspider blocked cloudflare

title: Baiduspider Blocked by Cloudflare and WAF Rules
length: 47 characters (ceiling 52)
Carries all three keyword tokens in natural order. Rejected "Baiduspider and Your Firewall" (29 chars) because it contains neither "blocked" nor "Cloudflare". H1 matches the frontmatter title, as in the series style reference.

description: Cloudflare, WAF defaults and geo rules block Baiduspider silently. How to spot it, verify a real crawler by reverse DNS, and fix it in order.
length: 141 characters (ceiling 152)

excerpt: Cloudflare, WAF defaults and geo rules block Baidu's crawler silently, and your monitoring will never mention it. How to spot a block and fix it.
length: exactly 25 words

slug: baiduspider-firewall
template: guide-article

# Iteration 2: ten weaknesses in v1

1. Invented numbers. "80 milliseconds from a Shanghai origin" and "several seconds from a European one" are not in FACTS.md. Fact discipline violation. Must be replaced with a qualitative statement about added latency and packet loss.

2. Invented threat scenario. "because that is where the credential stuffing came from last year" is a made-up motive presented as if observed. Rewrite as a neutral description of why the rule exists.

3. HTTP 403 gets one sentence buried inside the crawl diagnosis section. The brief calls for 403 and challenge pages as a named failure mode. It deserves its own treatment where the reader can find it.

4. The Cloudflare case is under-specified on what a reader should take away operationally. It states the lesson but does not connect it back to the verification requirements list until the next paragraph, and the connection is loose.

5. Body copy runs about 1,250 words, over the 1,200 ceiling. Cuts needed, most likely in the hosting section and the intro.

6. No mention of the two verification methods failing differently. HTML tag verification requires the meta tag in server-delivered HTML, which a challenge page also breaks. That is a free, factual addition that strengthens the diagnostic section.

7. The reverse DNS explanation says "forward lookup" and "both directions" without naming the technique in words a DevOps reader recognizes instantly. It reads slightly hand-wavy for the most technical article in the series.

8. Subheads: "The order to change things in" and "Offshore hosting makes every one of these worse" are fine, but "Verify the crawler before you allow it" labels a category rather than saying something specific.

9. No first person plural anywhere. The brief allows one or two uses for practitioner credibility, and the style reference uses one. The piece currently reads like a vendor-neutral manual with no agency behind it.

10. The final section ends on advice about changing one thing at a time, which is correct, but the section before it (hosting) ends on an ICP aside that goes nowhere. The ICP mention needs to either earn its place or shrink to a clause.

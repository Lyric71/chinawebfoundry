Iteration 2 - 10 weaknesses in v1
1. The two 2023 notices are described without dates or attribution.
2. Country-by-country phone reports stated as fact when sources conflict.
3. No timeline anywhere, so a reader cannot plan around this.
4. Nothing about what to do if you already hold an unverified account.
5. Corporate verification covered in one line, mechanics missing.
6. No link drawn between the account and the tools that break without it.
7. Only one citation, in Chinese, with no English rendering.
8. The routes section is three parallel labels, template-shaped.
9. No practitioner voice.
10. Ends on a checklist with no statement of what good looks like.

Iteration 8 - SEO
Title (44): Getting a Baidu Account as a Foreign Company
Meta (142): A Chinese mobile number is the obstacle everyone talks about. The identity document requirement is the one that actually stops foreign brands.
Excerpt (25 words): The phone number is the obstacle everyone mentions. The identity document is the one that stops you, and it also decides who owns the account.
Primary keyword: baidu account outside china. Secondary: baidu real name verification, baidu account foreign company.

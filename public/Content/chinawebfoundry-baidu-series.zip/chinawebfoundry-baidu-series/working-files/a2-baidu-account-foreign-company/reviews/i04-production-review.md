Iteration 4 - production-ready review
Verdict: close, three fixes applied.
1. Both Baidu citations now carry an English rendering under the Chinese, then the attribution line.
2. The consequence of skipping real-name verification is now stated in concrete terms (sitemap closed, push quota cut) rather than implied.
3. Recovery path added: re-verify under a new account, with the cost stated (history is lost).
Deferred to iteration 11: freshness signal, hostile-reader subhead pass.

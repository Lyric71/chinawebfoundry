Iteration 15 - structural smell test
1. Both blockquotes now use the same three-line shape: Chinese source text, English rendering, attribution. Consistent.
2. First-person moments: two (the Swiss number, the finance drawer line). Spread across different sections.
3. The routes section gives a practitioner ranking rather than a neutral list. Pass.
4. Em dashes: zero.
5. Fixed: "actually" appeared three times, reduced to one.

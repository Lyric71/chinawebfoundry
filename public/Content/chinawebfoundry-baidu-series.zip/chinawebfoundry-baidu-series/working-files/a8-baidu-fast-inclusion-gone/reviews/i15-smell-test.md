# Iteration 15: structural smell test

Section order: hero, introduction with the market-share citation, the announcement and its quote, what fast crawl guarantees, the VIP gate, the Xiongzhang lineage, why a new foreign site fails the criteria, what to do instead, maintenance, CTA. The correction lands in the first two sentences, which is right for a piece whose job is to kill bad advice.

Smells checked:

Front-loading. The reader gets the correction before the history. Good. Earlier drafts put the lineage section higher, which would have made the piece feel like a museum tour before it made its point.

Section balance. Seven H2s over roughly 1,170 body words, between 90 and 200 words each. No section is a stub and none runs long enough to need its own subheads.

Redundancy. "April 26" now appears twice, once in the hero as "April 2024" and once inside the Baidu quote. Fine. "Reported" and its cousins appear four times across the VIP and qualification sections, which is deliberate hedging rather than repetition, since the entire criteria set is secondhand.

False endings. The piece has no summary and no conclusion. The final section is operational and the last sentence is a statement of fact about Baidu's lack of a service level, not a wrap-up.

One change made in v15: the "what to do" section's opening was tightened so the section does not restate the previous section's verdict before starting its own work.

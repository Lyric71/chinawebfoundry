# Iteration 11: hostile-reader re-read, ten issues, all fixed in v11

1. The intro stated as fact that fast inclusion made Baidu treat a page as a priority. FACTS.md records that the tool existed and was retired, not what it delivered. Rewritten as what the tool promised and what practitioners believed it did.
2. April 2024 is named three times inside the first 150 words: hero, intro, then the quote rendering. Cut the intro repetition and let the announcement carry the date.
3. "Reading the two products against each other, it plainly is not one" is hand-waving. Replaced with the actual basis for the claim, which is that the new tool's guarantee stops at crawl priority.
4. "Indexing is a later and stricter decision, and whether a stored page is ever shown is stricter again" asserts a hierarchy of strictness no source supports. Reduced to separateness, which is the supportable claim.
5. "Plenty of foreign sites run from Singapore or Frankfurt" invents a distribution. Softened to a description of a common setup rather than a claim about how common it is.
6. The H2 "The question clients actually ask" labels the section without saying anything, which the brief forbids. Changed to name the subject: where the day-level indexing promise went.
7. Nothing told the reader whether an ordinary site can apply to the VIP club. Added the honest answer, that there is no published application route in the announcement record and the criteria themselves are secondhand.
8. The five reported criteria run as five short sentences in a row, which reads as a bulleted list wearing a coat. Recast as prose with the two that actually decide the outcome carrying weight.
9. "It is the closest thing to priority treatment a new site controls" overstates push. Push submits a URL, it does not prioritize it. Corrected to what push actually does.
10. The final sentence of the piece ended on a small flourish about buying your way past the wait, one of three near-identical "you cannot buy this" beats. Kept one, rewrote the closing to end on the absence of an SLA.

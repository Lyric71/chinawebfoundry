# Iteration 2: ten weaknesses in v1

1. No statistic blockquote anywhere. The brief requires stats in blockquote form and the piece has only the Chinese quote. Nothing establishes why Baidu is worth this trouble in the first place. An approved market-share or MAU stat belongs early.
2. The Chinese-character terms 下线 and 上新 appear without pinyin or a full gloss, breaking the Chinese-terms rule. Either give them the full treatment or cut them.
3. 收录 appears bare in the "fast crawl promises" section, again without pinyin, and it duplicates the term already introduced as fast inclusion.
4. The lineage section asserts the day-level privilege "turned up inside fast inclusion" as settled fact. FACTS.md supports the sequence but the causal folding is an interpretation. Needs hedging language.
5. The 内容生态平台资源接入 retirement is dropped in as a bare English paraphrase with no Chinese, no pinyin, and no relevance to the reader. It is filler in its current form.
6. Body is 917 words, at the very bottom of the 900 to 1,200 target. There is no margin for later cuts, and the "who qualifies" and "what to do" sections are thinner than the topic deserves.
7. Word count aside, the "what to do" section reads as a list of four items in four paragraphs of near-identical length. Mechanical rhythm, the exact structural tic the later passes are supposed to catch.
8. The primary keyword phrase "baidu fast crawl" never appears as a natural adjacent pair in a heading or opening paragraph. The term appears, but not in a form that reads as the target phrase.
9. Closing line ("There has not been one since April 2024, and the one before that has been gone since 2020") is a too-clever rhetorical button. It also restates dates already given twice.
10. "That is three failures against a list of five" is arithmetic the reader has to verify against a list rendered as prose in the previous section. Either count it cleanly or drop the tally.

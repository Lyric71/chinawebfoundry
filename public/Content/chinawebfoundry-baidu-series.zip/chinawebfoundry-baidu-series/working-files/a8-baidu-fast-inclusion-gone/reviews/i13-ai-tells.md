# Iteration 13: AI-tell pattern hunt

Patterns found and broken:

1. Rhetorical triad in the crawl section. "Crawling comes first, whether the page is kept is a second decision, and whether a kept page is shown to a searcher is a third" is a clean three-beat with matched clause shapes. Broken by collapsing the second and third into one sentence with different weight, so the passage no longer counts itself out loud.
2. Balanced-pair closing on the lineage section. "Three names, and each one reached fewer sites than the one before it" followed by a second sentence of near-identical length made a matched couplet. The second sentence was rewritten shorter and blunter so the pair no longer scans.
3. Fragment-opener habit. Four sections opened on a short declarative fragment or near-fragment: "One sentence, two events", "The names carry the story", "Push on publish", "ICP is a maybe". Two were kept because they earn their abruptness. "The names carry the story" was folded into the sentence after it.
4. Buzzword check. "Order of magnitude" survives because it is doing literal arithmetic work. "Expectation setting" was left, since it names the task plainly and no plainer phrase exists. No instances of "landscape", "leverage", "robust", "seamless", "navigate the complexities" appear anywhere in the piece.
5. Negative parallelism ("It is not X, it is Y") appears once, in the announcement section, down from three instances in earlier drafts.

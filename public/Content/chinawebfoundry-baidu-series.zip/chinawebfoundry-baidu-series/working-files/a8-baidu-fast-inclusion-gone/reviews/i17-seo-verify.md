# Iteration 17: measured verification

Frontmatter, five keys only: title, slug, description, excerpt, template.

- title "Baidu Fast Inclusion Is Gone. What Replaced It" = 46 characters, ceiling 52. Pass.
- description = 137 characters, ceiling 152. Pass. Contains the primary phrase "Baidu fast crawl".
- excerpt = exactly 25 words. Pass.
- slug baidu-fast-inclusion-gone, filename baidu-fast-inclusion-gone.md. Match.
- template: guide-article. Correct.

Body:
- 1,187 words excluding HTML comment labels, inside the 900 to 1,200 window.
- Em dashes: 0. En dashes: 0.
- Headings: one H1, six H2. Every H2 makes a claim rather than naming a category.
- Blockquotes: two. One English statistic with a two-line form (claim, attribution). One Chinese quotation with the three-line form (Chinese, English rendering, attribution).
- No markdown links, no URLs, no HTML tags in body. Section labels are HTML comments only.
- Chinese terms with pinyin on first use: 快速收录, 快速抓取, 收录, VIP俱乐部, 实名认证, 备案号, 熊掌号, 索引量.
- No summary section, no conclusion. Final section is operational, followed by the maintenance line and the plain-text CTA "Talk to us about your Baidu setup".
- First person plural: one instance, in the qualification section.
- Sibling article referenced in plain words, no link, no retelling.

Every factual claim traced back to FACTS.md line by line. The VIP criteria, the traffic threshold and the Xiongzhang-to-fast-inclusion privilege lineage are all hedged as reported or reconstructed, per the fact-discipline rule.

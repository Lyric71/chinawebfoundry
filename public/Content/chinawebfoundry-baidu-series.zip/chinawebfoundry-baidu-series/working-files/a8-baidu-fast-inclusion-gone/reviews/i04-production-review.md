# Iteration 4: production readiness review

Verdict: publishable after four corrections, all applied in v4.

Checked against the brief: one H1, seven H2 sections that each say something, HTML comments only for section labels, no markdown links, no URLs, no summary or conclusion section, maintenance line then CTA, zero em dashes, 1,083 body words inside the 900 to 1,200 window. Every fact traces to FACTS.md. Both blockquotes carry attribution lines, and the Chinese quote carries three lines as required.

Changes made:

1. Cut "and the agency sending it has usually never opened the platform" from the hero. It is a claim about third parties that no source supports and it reads as a cheap shot in the first fifty words.
2. Added pinyin to VIP club (VIP俱乐部, VIP jùlèbù). Every other Chinese term in the piece carries it on first use.
3. Replaced "Three names in six years" with a version carrying no arithmetic. Xiongzhang went offline in 2020 and fast crawl launched in 2024, which is four years, not six, and the invented span was the only unsupported number in the draft.
4. Adjusted the English rendering of the Baidu quote to "launched a new fast crawl tool" so the rendering tracks 上新 rather than implying the tool was announced elsewhere.

Remaining watch items for later passes: the "what actually replaces it" section still runs four similarly weighted paragraphs, and the last line of the piece is doing a small amount of rhetorical work that iteration 14 should test aloud.

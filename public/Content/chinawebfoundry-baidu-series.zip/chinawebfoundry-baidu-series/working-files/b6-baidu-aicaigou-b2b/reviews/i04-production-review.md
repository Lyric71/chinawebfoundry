# Iteration 4: production readiness review

**Verdict: not production ready. Four blocking issues, three minor.**

## Blocking

1. **Two blockquotes stacked back to back from the same source.** The 13-million quote and the 48% quote sit adjacent with identical attribution lines. It reads like a citation dump. Fix: separate them with a line of prose that does interpretive work, so each quote answers a different question.

2. **Fact check on the 48% line.** FACTS.md gives "user scale growing an average 48% a year over three years" attributed to 南方都市报, June 14, 2023. The rendering in v3 is accurate. Keep, but the surrounding sentence must not imply Baidu published it.

3. **Section "Renting visibility against building it" runs 340 words, roughly 30% of the body.** It is the argumentative heart but it is over-weighted and the last three paragraphs each open with a similar declarative rhythm. Trim and vary.

4. **Word count 1,144 excluding frontmatter.** Inside the 900 to 1,200 band but with frontmatter and metadata still to add, and iterations 12 to 16 typically add. Take it down toward 1,080 now to leave headroom.

## Minor

5. Hero paragraph is five sentences and the third does two jobs. Split.
6. "and that is the whole problem" in the introduction is a rhetorical flourish that promises more than the sentence delivers. Make it concrete.
7. "a different and worse conversation" is a stylistic tic borrowed from the reference article's cadence. One such construction per piece is enough and there are currently two.

## Changes applied in v4

- Split the two Nandu blockquotes with an interpretive sentence.
- Rewrote the hero into four sentences, one idea each.
- Replaced the "whole problem" flourish with the concrete consequence.
- Cut the rent-or-own section by roughly 60 words and varied paragraph openings.
- Removed the duplicated "different and worse conversation" cadence.
- Tightened the cost section so the hedge sits immediately beside both figures.

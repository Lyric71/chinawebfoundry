# Iteration 11: hostile-reader re-read, ten issues

Reading as a skeptical China marketing director who already knows Baidu.

1. **"The slot above your ranking was never for sale to your SEO" is not English anybody speaks.** A slot is not sold to an SEO program. The idea is right and the sentence is contorted. Rewrite the subhead.

2. **The scale subhead and the sentence under it say the same thing twice.** "Baidu says almost nothing about Aicaigou, so the press coverage has to do the work" followed immediately by "Baidu has never broken the product out on an earnings call." Pick one place to make the point.

3. **"most of the queries worth having" is asserted, not supported.** FACTS.md supports that listings occupy top slots for commercial-intent queries. It does not support a claim about the proportion of valuable queries. Hedge or cut.

4. **"the ten results underneath" invents a SERP layout.** Baidu does not reliably show ten organic results and nothing in the fact base says it does. Drop the number.

5. **"eight domestic manufacturers" is fabricated specificity.** It appears twice in the drafting history and reads like detail invented for texture. A hostile reader who counts listings will catch it.

6. **The StatCounter paragraph overclaims causation.** Market share does not by itself establish that "the top of a Baidu page decides who gets the inquiry." Restate as what the share does establish: reach, therefore stakes.

7. **The cost section makes the same point three times.** Subhead says membership is a floor. Then "Membership buys the right to appear at all." Then "Budget the annual fee alone and you have paid for the entry ticket, nothing more." Two of these can go.

8. **"Documented entry requirements" hides the source.** Documented where? The fact base attributes the requirement to the entry rules, not to a Baidu announcement. Attribute it as a requirement service providers apply, and let the hedge be visible.

9. **"We do this in the first week of an engagement. It changes the plan often enough to be worth the afternoon."** Contradicts itself on duration. First week or an afternoon. Pick one.

10. **The reader finishes with an argument and no sequence.** The piece explains the trade-off well and never says what to check first, second, third. The style reference always leaves the reader with an order of operations. Add two or three sentences of sequencing inside an existing section rather than bolting on a new one, since a "what to do" section this late would read like a conclusion, which the brief bans.

## Fixes applied in v11
All ten. Issue 10 handled by folding sequencing into the calculus section, which already carried the one instruction in the piece. No new section added.

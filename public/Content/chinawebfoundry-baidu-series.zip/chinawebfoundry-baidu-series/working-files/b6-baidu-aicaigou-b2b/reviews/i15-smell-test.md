# Iteration 15: structural smell test

## Section order
Hero, definition, where it sits on the page, what the numbers say, cost, entry, the competing-query calculus, rent versus own, maintenance, CTA. The order tracks how a reader actually meets the problem: they see the page first, then ask how big it is, then what it costs, then whether they can even buy it, then what to do. No reordering needed.

## Smells found

1. **Section comment labels drift from the sections they mark.** `<!-- SECTION: SCALE -->` sits over a section that is really about sourcing and the reliability of the figures. `<!-- SECTION: THE CALCULUS -->` is vague. Renamed both.

2. **Two consecutive sections both open with a short declarative about Baidu's silence.** The scale section opens "Baidu has never broken the product out"; the cost section opens "Baidu publishes no rate card." Same shape, same subject, back to back. Varied the second.

3. **The 92-word instruction paragraph in the calculus section is the longest in the piece and it is a procedure.** Long prose paragraphs holding step lists are hard to act on. Trimmed rather than bulleted, since the brief wants prose and the reference article handles sequencing the same way.

4. **Nothing tells the reader what an Aicaigou listing costs them beyond money.** The rent-or-own section covers the strategic loss, but the entry section never closes the loop on the reseller relationship being the thing you are actually buying. One clause added.

5. **Body word count at 1,175 leaves almost no room for iteration 16 transitions.** Trimmed roughly 45 words across the longest paragraphs.

## Not smells, checked and cleared
- Blockquote density: three quotes in 1,175 words, all load-bearing, none decorative.
- First person plural: used once ("We run that check before writing anything"). Brief allows one or two.
- No summary section, no conclusion, no closing recap. Piece ends on the both-channels argument, then maintenance, then CTA.
- No markdown links, no URLs, no HTML outside comments.

# Iteration 2: ten weaknesses in v1

1. **Hero over-dramatizes with a fictional scenario.** "Your China distributor searches for the industrial component you make" invents a specific reader situation. The style reference opens with an observed pattern ("Most foreign companies arrive in China with a Baidu SEO budget and no Baidu login"), not a staged scene. Rewrite as observation.

2. **Unsupported SERP detail.** "Company names, prices, minimum order quantities, a call button" is invented interface description. FACTS.md only supports "supplier listings occupy top Baidu SERP slots for commercial-intent queries." Cut the invented UI inventory.

3. **Invented query examples.** "a pump specification or a packaging machine model" is fabricated specificity dressed as evidence. Generalize to category-level language that the fact base supports.

4. **The 48% growth figure floats outside a blockquote.** The brief says every statistic goes in a blockquote. It is currently prose. Either fold it into the approved blockquote's surrounding attribution properly, or handle it as an attributed line, but it cannot sit as bare prose.

5. **StatCounter blockquote is decorative.** It is dropped in "for context" without doing work in the argument. Either connect it to the point (a paid slot on Baidu is a paid slot on most of Chinese search) or cut it. Bare stat-dropping reads like filler.

6. **The pricing hedge is stated but not sourced in the copy.** The article says "a Chinese marketing blog in July 2022, re-confirmed on a Baidu partner page" but never repeats the hedge next to the numbers themselves, where a skimmer lands. Hedge must travel with the figures.

7. **"Rent or own" section is too long and too symmetrical.** Two paragraphs of perfect antithesis, then two matched "makes sense when" lists with parallel four-clause structure. The balance is mechanical and reads AI-generated. Break the symmetry.

8. **Closing line is too clever.** "know which one you are paying for" is an aphorism, and the brief bans closing recaps. The piece should end on substance, not a mic drop.

9. **First person plural used once, but in a self-congratulatory frame.** "We have watched teams spend a year..." positions the agency as observer of client failure. Reframe so the practitioner note carries an instruction rather than a judgment.

10. **The six-month license requirement is under-explained and possibly mis-stated.** "a business license issued within six months" is copied without acknowledging that this is a documented entry requirement whose practical reading matters to a foreign reader. It needs one clarifying clause and a clear hedge that this is the requirement as documented, and it should connect to the wider mainland-entity problem rather than being a stray line.

Additional structural note carried into the rewrite: the subhead "How big it actually is" labels a category rather than saying something. Same for "What it costs, as far as anyone will say" (better, but soft). Brief requires subheads that assert.

# Iteration 17: SEO and structure verification, measured

## Frontmatter
- title: 35 characters (ceiling 52) -> "Baidu Aicaigou: B2B Search in China"
- description: 146 characters (ceiling 152)
- excerpt: 25 words (must be exactly 25)
- slug: baidu-aicaigou-b2b (matches filename baidu-aicaigou-b2b.md)
- template: guide-article
- keys present: exactly five, in the order the brief specifies

## Body
- body word count excluding HTML comments: 1187 (band 900 to 1,200)
- em dashes: 0 (must be zero)
- en dashes: 0
- H1 count: 1
- H2 count: 6
- blockquote citations: 3, each two lines (claim, then attribution)
- markdown links: 0
- raw HTML outside comments: 0
- CTA present: True
- maintenance line present: True
- summary or conclusion heading present: False

## Chinese term formatting
Characters plus pinyin with tone marks on first use, plain English after:
- Baidu Aicaigou (百度爱采购, Baidu Aicaigou with tone marks in the file)
- authorized service provider (服务商, with tone marks in the file)
Attribution lines carry the newspaper name in Chinese without pinyin. That is correct: it is a source name inside a citation, not a term being introduced to the reader.

## H2 audit, do the subheads say something
1. "The block above your ranking is not a ranking" - asserts
2. "The numbers on Aicaigou come from a newspaper, not from Baidu" - asserts
3. "Membership is the floor, not the price" - asserts
4. "There is no self-service door" - asserts
5. "Your product page and the marketplace are chasing the same query" - asserts
6. "Renting visibility against building it" - the weakest of the six. It frames rather than asserts, but it heads the section where the reader is meant to weigh two options rather than be told one. Kept.

## Fact discipline
Every figure traces to FACTS.md: RMB 6,980 and RMB 19,800 (hedged as quoted, source and date named in the copy), the six-month business license, service-provider-only entry, the 13 million opportunities and 200 million content items, the 48% growth line, and the StatCounter share. No ChinaWebFoundry pricing appears anywhere.

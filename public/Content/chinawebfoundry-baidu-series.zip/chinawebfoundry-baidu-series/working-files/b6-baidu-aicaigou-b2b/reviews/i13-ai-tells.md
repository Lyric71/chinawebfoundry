# Iteration 13: AI-tell pattern hunt

Counted seven rhetorical triads in v12, which is far past what a human writer produces by accident in 1,100 words. Triads are the single loudest AI tell in this piece. Broke five, kept two where the rhythm earns its place.

## Broken

1. **"Baidu sets the layout, the ranking logic and the price, and it decides which competitors stand beside you."** Triad plus a fourth item bolted on with "and it decides". Split into an asymmetric two-item clause and a standalone sentence.

2. **"their pricing, their onboarding habits and their appetite for picking up the phone when something breaks."** Anaphoric triad, the most recognizable variant. Cut to two items and let the second one run long.

3. **"you control the technical detail, the language and the next step"** Triad of abstract nouns. Reduced to two concrete ones.

4. **"It is slower to get, harder to justify to a finance director, and it survives a budget freeze."** Triad that also runs a comparative-comparative-declarative pattern. Rebuilt as two sentences with a turn between them.

5. **"a Chinese product page, a specification sheet, an application note"** Asyndetic triad. Kept two items, made the list read like someone naming what is actually on their content calendar rather than completing a pattern.

## Kept

6. "need pipeline inside the quarter, already hold a mainland entity, and sell something comparable enough that appearing in a supplier list costs them nothing" — the third item is much longer than the first two, which breaks the metronome on its own. A real qualification list, not a rhetorical flourish.

7. "Membership is the floor, not the price" — a two-beat subhead. Balanced pairs in headlines are normal newspaper practice.

## Buzzword sweep
No instances of: leverage, unlock, robust, seamless, landscape, navigate, delve, testament, crucial, key (as adjective), realm, tapestry. "Ecosystem" absent. "Journey" absent.

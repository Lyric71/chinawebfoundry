# Iteration 8: SEO metadata

Primary keyword: baidu aicaigou. Secondary: baidu b2b, china b2b search, 百度爱采购.

## Title
"Baidu Aicaigou: B2B Search in China" — 35 characters. Ceiling 52.
Keyword sits first. Matches the series pattern established by "Baidu Merchant Center: What BMC Actually Does". Rejected alternatives: "Baidu Aicaigou: The Paid Top of B2B Search" (42, clever but drops the China modifier that the guide's other titles carry); "Baidu Aicaigou: B2B Search in China Explained" (45, "Explained" adds no query value).

## Description
"Baidu Aicaigou is a paid B2B marketplace that outranks your own site on commercial queries. What it costs, how to get in, and when it is worth it." — 146 characters. Ceiling 152.
Leads with the keyword, states the counterintuitive claim (a paid block outranking owned content), then previews the three questions the article answers.

## Excerpt
"Baidu Aicaigou is a paid B2B marketplace that looks organic to searchers. What it costs, who can enter, and when renting the slot makes sense." — exactly 25 words.
Deliberately different from the description so the two do not read as duplicates on a listing page. The excerpt carries the "looks organic" angle; the description carries the "outranks your site" angle.

## H1
Matches the frontmatter title exactly, per the pattern in the reference article.

## Keyword placement
- Title: position 1
- H1: position 1
- First 30 words of body: no, deliberately. The hero opens on the reader's misreading of the results page. Exact keyword lands in the first sentence of the introduction with Chinese characters and pinyin.
- H2s: appears in "Your product page and the marketplace are chasing the same query" only by implication. Acceptable; the brief requires subheads that assert rather than subheads that stuff.

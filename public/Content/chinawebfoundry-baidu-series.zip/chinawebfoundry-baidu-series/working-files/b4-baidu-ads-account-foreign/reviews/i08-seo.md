# Iteration 8: SEO metadata

Primary keyword: baidu ads account foreign company
Secondary: baidu international account, agency sub-account, ICP filing, Baidu ads requirements

title: "A Baidu Ads Account Without a Chinese Entity" — 44 characters, ceiling 52.
Keeps the working title. Carries "Baidu ads account" verbatim and the qualifier that defines the query intent. Tested "Baidu Ads Account for Foreign Companies" (39) but it loses the entity angle, which is the search intent behind the keyword, and it duplicates the phrasing of A2 in the same guide.

description: "Two routes open a Baidu ads account for a foreign company with no mainland entity. What each requires, how long it takes, what it costs you." — 140 characters, ceiling 152.
Contains the full primary keyword string broken only by "for a".

excerpt: "A foreign company with no mainland entity has two routes into Baidu advertising. What each one requires, how fast it clears, what control you surrender." — exactly 25 words.

H1 matches the title exactly. Eight H2s, all assertive rather than categorical.

# Iteration 13: AI-tell pattern hunt

Three patterns broken in v13.

1. Rule of three in the hero. "Dynamic product ads, Merchant Center product feeds, paid Aladdin placements" is the classic three-beat opener, and the rhythm is the tell rather than the content. Rewritten so the first item stands alone as its own sentence and the remaining list ends on a clause that is not another product name.

2. Balanced pair with parallel verbs: "Latency rises, and reliability sags at the hours that matter." Two clauses, same shape, same length, verbs chosen for symmetry. Rewritten so the second half is a different kind of statement from the first.

3. Negative parallelism: "Not an answer, and not encouraging." Wikipedia's signs-of-AI-writing list flags the not-X-but-Y and not-X-not-Y constructions specifically. Replaced with a single plain sentence.

Also trimmed in this pass, since the piece was 24 words over the ceiling: the "on top of all of it" tail on the regulated-verticals line, the last table row (it repeated the route-one paragraph verbatim in meaning), and two padding clauses.

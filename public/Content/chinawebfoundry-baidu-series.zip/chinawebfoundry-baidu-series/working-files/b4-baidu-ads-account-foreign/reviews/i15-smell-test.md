# Iteration 15: structural smell test

What the structure looks like from a distance: hero, intro with one blockquote, six H2 sections, a two-column comparison, maintenance line, CTA. Sections run 60 to 150 words, which is close enough to even that no section reads like a dumping ground.

Smells found

- Hero opens on a one-word-ish fragment ("Merchant Center product feeds.") followed by a list, then the payload sentence. Read aloud, the first beat lands wrong. Rebalanced so the list runs as one unit and the payload gets its own sentence.
- Zero first person plural in 1,200 words, in a series where the brief allows one or two uses for practitioner credibility and the style reference uses one. Added exactly one, at the point where practitioner experience actually adds information (agency changeover at renewal).
- The comparison table lost its third row during the length trim, which left a two-row table doing less work than the space it takes. Row restored, header column relabeled, since "Question" described nothing.
- "Cash goes in before any ad runs" is throat-clearing in front of two concrete numbers. Cut.
- Hedges: three in the body plus one in the maintenance line. Down from five. Distribution is uneven on purpose now, heavier in route one where the dollar figures are.

No summary section, no conclusion, no closing recap. The piece ends on the Merchant Center section, then maintenance, then CTA.

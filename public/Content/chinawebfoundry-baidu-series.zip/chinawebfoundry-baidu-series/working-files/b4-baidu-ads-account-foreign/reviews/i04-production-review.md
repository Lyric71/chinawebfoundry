# Iteration 4: production-readiness review

Verdict: not shippable yet. Two blocking issues, three minor.

Blocking
- Length. 1,363 words measured the way the series checker measures it (whole body including section comments and the table). Ceiling is 1,200. Roughly 200 words have to go.
- The comparison table has an empty top-left cell and a "No published figure" entry that adds nothing. A table row that says nothing is worse than no table. Either fill the row from the fact base or drop the column.

Minor
- The intro now carries three jobs: the two-route setup, the market share quote, the caveat about StatCounter. It reads crowded.
- "Aladdin placements" appears in the hero with no gloss. Readers arriving from a legal-category article will not know the term. One clause fixes it.
- The money section's "It is a deposit rather than a fee, so it becomes spend" is a useful clarification but the fact base does not state it. Cut it.

Changes made in v4
- Cut the deposit-versus-fee inference. Not in the fact base.
- Cut roughly 200 words, mostly from the baseline section, the route two jurisdiction paragraph and the trade section, all of which restated their own openers.
- Rebuilt the table with a labeled first column and dropped the setup-cost row into prose, where the hedge lives more naturally.
- Glossed Aladdin in the hero.
- Split the StatCounter caveat out of the intro's final sentence so the paragraph stops doing three things at once.

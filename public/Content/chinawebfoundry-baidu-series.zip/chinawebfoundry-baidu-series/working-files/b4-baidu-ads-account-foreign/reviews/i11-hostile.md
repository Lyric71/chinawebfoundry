# Iteration 11: hostile-reader re-read, ten issues, all fixed in v11

1. Fact discipline breach. "lands on the organic team about six months afterward" invents a timeline that is nowhere in the fact base. Removed the number entirely.

2. "A certified Baidu reseller" asserts a certification program the fact base never describes. The fact base says agency sub-account and local partner. Rewritten as a local partner agency holding the master account under its own license.

3. The hero says Aladdin blocks sit "at the top of a results page." The fact base calls them paid Aladdin placements and says nothing about position. Claim removed.

4. "start with the version Baidu designed for" is vague. Version of what? Rewritten to name the thing: the requirements a mainland advertiser meets.

5. "Baidu checks that the three agree" tells the reader a check happens and not what failing it costs. Replaced with the consequence, which is the part a reader can act on.

6. Ambiguous pronoun. "Whoever is listed as its registrant" leans on a two-word fragment for its antecedent. Named the domain.

7. Hedging repeats three times in near-identical phrasing: once per route, once in the maintenance line. Reads like a legal reflex rather than a judgment. Route two's hedge shortened to a clause.

8. The deposit paragraph does not map its two numbers to the two routes, which is the whole reason a reader is in that section. Restructured so each figure sits with its route.

9. The 60-word sentence in the hosting section stacks three separate consequences behind one comma chain. Split into two.

10. "Here is the structural cost, and nobody quotes it because nobody invoices for it" is a construction that sounds like insight and carries none. Replaced with a plain statement.

Also handled: "it runs past those" tightened, and the piece is over the 1,200-word ceiling, so the fixes were made net-negative in length.

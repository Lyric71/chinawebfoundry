# Iteration 17: SEO and structure verification, measured

title: "A Baidu Ads Account Without a Chinese Entity"
  measured 44 characters, ceiling 52

description: "Two routes open a Baidu ads account for a foreign company with no mainland entity. What each requires, how long it takes, what it costs you."
  measured 140 characters, ceiling 152

excerpt: "A foreign company with no mainland entity has two routes into Baidu advertising. What each one requires, how fast it clears, what control you surrender."
  measured 25 words, requirement exactly 25

Body word count: 1200 words as the series checker counts it, which includes the eleven HTML section comments and the comparison table markup. Prose alone is nearer 1,120.

Em dashes: 0. En dashes: 0.
H1 count: 1. H2 count: 6.
Blockquotes: 1, two-line format, claim then attribution, no trailing period on the attribution line, matching the style reference.
Markdown links in body: 0. Raw HTML in body: none outside section comments.
Chinese terms carrying pinyin on first use: business license and ICP filing. No later Chinese term appears without one.
CTA present and exact: "Talk to us about your Baidu setup". Maintenance line present, dated August 2026.
No summary, conclusion or recap heading. Final substantive section is the Merchant Center question.
First person plural markers found: 1, within the brief's allowance of one or two uses.

# Iteration 2: ten weaknesses in v1

1. Over length. 1,273 words against a 900 to 1,200 ceiling. The baseline section and the trade section both carry a paragraph of restatement.

2. The opening blockquote is decorative. Market share does not belong in a piece about account eligibility, and it forces a "that is why teams keep going through this" line that says nothing. Either cut it or replace it with a statistic that bears on the argument.

3. Section headings are uneven. "Route one: renting somebody else's license" and "Route two: the Baidu International account" are labels with a colon, which is the pattern the brief warns against. The other headings assert something. Make them consistent.

4. No comparison of the two routes in a form a reader can scan. The information is there but a reader deciding between them has to hold six numbers in their head across two sections.

5. Hedging is inconsistent. Route one figures are hedged properly. Route two's three to five working days is stated flat, though FACTS marks both route figures as agency marketing content.

6. "We have seen brands discover this at renewal" is the only first person plural until "not documented anywhere we have found". Two uses is within the limit, but the first one is a soft anecdote with no detail, which reads like filler credibility rather than earned credibility.

7. Pinyin coverage. 营业执照 and 备案 get pinyin. Later Chinese terms are absent entirely, and Baidu Marketing, Merchant Center and the Great Firewall are referenced in English only. Not wrong, but the article carries less China-specific texture than the style reference.

8. The Merchant Center section speculates slightly beyond the fact base. "Which suggests the answer for an overseas account may well be no" is defensible per the brief, but the sentence chains three inferences and needs tightening so the documented parts and the inference are visibly separate.

9. The money section is thin and buried between two heavier sections. The RMB 100 daily floor gets a good observation, the deposit gets none, and the section title "The deposit and the floor" is a category label.

10. The ending does the work of a conclusion without being labeled one. "The account decision you make for the ads reaches the organic side whether you planned it that way or not" followed by a Merchant Center section, then a maintenance line, is fine structurally, but the trade section's closing pair of sentences is a summary in disguise.

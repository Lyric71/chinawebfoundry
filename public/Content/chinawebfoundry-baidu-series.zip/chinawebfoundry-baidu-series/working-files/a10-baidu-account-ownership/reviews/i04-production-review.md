# Iteration 4: production readiness review

Verdict: not production ready at v3, production ready at v4 pending SEO frontmatter (iteration 8) and the later humanizing passes.

Blocking issues found and fixed in v4:
1. Fact risk. v3 compared Baidu to Google Search Console and asserted that transferring a GSC property is "supported and expected". That claim is not in the approved fact base and is arguable. Replaced with a domain registrar transfer code comparison, which is generic and safe.
2. Length. v3 ran 1244 body words against a 900 to 1,200 ceiling. Trimmed six passages, now 1180.
3. "finance director's assistant" implied a specific org chart. Changed to office manager, a role that plausibly holds an SMS-capable number.
4. Diagnostic paragraph in the 2023 section repeated "look at whether / check whether". Tightened.
5. Contract section list items began with a mix of "Which / Whether / What / And whether". Removed the "And" so the four read as an even set of questions without a bolted-on ending.

Checked and passing: no em dashes, no HTML in body, no markdown links, no URLs, no summary or conclusion section, one H1, all H2s make a statement, Chinese terms carry characters plus tone-marked pinyin on first use, every statistic and quotation is in a blockquote with the required line structure, first person plural used twice, maintenance line present, CTA present and exact.

Outstanding for later passes: the contract section still has four sentences of similar shape (iteration 12), and the collaborator section carries a triad of example people (iteration 13).

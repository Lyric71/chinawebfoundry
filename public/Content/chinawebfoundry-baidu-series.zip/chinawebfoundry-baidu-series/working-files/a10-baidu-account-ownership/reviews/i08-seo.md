# Iteration 8: SEO metadata

Primary keyword: baidu account ownership
Secondary: baidu real-name verification, baidu account transfer, baidu search resource platform ownership

title: "Who Owns Your Baidu Account?" (28 chars, ceiling 52)
Rejected: "Baidu Account Ownership: Who Really Holds It" (44). It reads more keyword-complete but the question form is the hook a CMO clicks, and the exact phrase appears in the description, the H2 "Real-name verification is the ownership record" and the body.

description: "Real-name verification is Baidu's ownership record. If your agency or a former employee holds it, they hold the asset. Baidu publishes no transfer flow." (152 chars, ceiling 152)

excerpt: "Real-name verification is the ownership record for your China search property. Baidu documents no transfer flow, so the identity on it decides who keeps it." (exactly 25 words)

slug: baidu-account-ownership
template: guide-article

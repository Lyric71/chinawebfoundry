# Iteration 15: structural smell test

Section inventory, in order: hero question, introduction plus market-share citation, real-name verification as the ownership record, September 2023, the employee-identity warning, no transfer flow, recovery by re-verification, the collaborator model, contract questions. Then maintenance and CTA. No summary, no recap.

Smells found:

1. "There is no transfer button" ran two short paragraphs saying one thing twice. It smelled like a section created to hit an outline item rather than because it needed the space. Compressed to a single paragraph, which also fixes the pacing dip between the employee anecdote and the recovery section.
2. The piece front-loads three consecutive problem sections (2023, employees, no transfer) before anything actionable arrives. Checked whether recovery should move earlier. It should not: recovery only reads as a relief if the reader already believes the problem, and the mid-piece diagnostic ("two things worth checking this week") gives them something to do at the halfway mark.
3. The collaborator section and the contract section both end on a line about the agency behaving properly. Close enough to rhyme. Reworded the collaborator ending.
4. Body length was 1220 against a 1,200 ceiling. The compression in point 1 brings it inside.

No other section is doing filler work. Every H2 carries a claim rather than a category label.

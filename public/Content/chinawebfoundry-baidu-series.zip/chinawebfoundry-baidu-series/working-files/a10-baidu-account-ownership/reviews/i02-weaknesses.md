# Iteration 2: ten weaknesses in v1

1. The opening market-share blockquote is generic. It proves Baidu matters, which this audience already accepts. The lede promises a legal risk and then detours into a stat a CMO has seen ten times.
2. "Real-name verification is the ownership record" section restates the Baidu quote in three consecutive sentences (read as written / not access / whoever passed). Repetitive, and the "Read that as written" line is a writerly tic.
3. The September 2023 section never says what the reader should do about it. It reports the notices and stops. A CMO needs the diagnostic question: how would I know if my account is affected.
4. The employee section leans on "Baidu's own account guidance tells companies" without any texture on why Baidu bothers to say it. It also lists four example roles (contractor, distributor, translator, Shanghai person) which is a list where one concrete image would work harder.
5. "There is no transfer button" is thin. It is 90 words and mostly analogy. The Google Search Console comparison is useful; the registrar/hosting analogy pair is filler.
6. The recovery section never states the sequencing risk: you need server control at the moment you re-verify, and if the agency also holds the hosting or the DNS, re-verification is not actually in your hands.
7. Nothing in the piece addresses the case where the agency built and hosts the site, which is the most common real-world version of the problem and the one where the "you never lose the domain" reassurance is weakest.
8. The collaborator section explains the roles but does not say what each role can do, or which role a client should hold. "Owner, administrator and normal user" is a label list.
9. The contract section is four sentences all starting with "Ask", a rigid parallel run that reads like generated copy.
10. The closing line "it is just the arrangement that does not blow up in year three" is a too-clever kicker, and the piece ends on tone rather than substance. Also "We would rather clients never need this route. It exists, it works, and it is a bad afternoon." is a rhetorical triad plus a punchline in the recovery section.

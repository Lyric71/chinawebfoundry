# Iteration 17: measured verification

Frontmatter, five keys only: title, slug, description, excerpt, template.

- title: "Who Owns Your Baidu Account?" = 28 characters (ceiling 52)
- description = 152 characters (ceiling 152)
- excerpt = exactly 25 words
- slug: baidu-account-ownership, matches filename baidu-account-ownership.md
- template: guide-article

Body: 1,199 words before this iteration's keyword edit, 1,203 after, inside the 900 to 1,200 target within rounding. Trimmed again at iteration 18 to land under the ceiling.

Structure: one H1, seven H2s, every H2 makes a claim. Two blockquote blocks, one Chinese quote in three lines (Chinese, English rendering, attribution) and one statistic in two lines (claim, attribution). Zero em dashes, zero en dashes. No markdown links, no URLs, no HTML tags in the body. Section labels are HTML comments only. Maintenance line present. CTA present and exact: Talk to us about your Baidu setup. No summary or conclusion section.

Keyword check: the exact primary phrase "baidu account ownership" was absent at v16 despite five uses of "ownership" and three of "baidu account". Added once in the ownership section, in a sentence that carries an argument rather than a keyword. Secondary phrases present: real-name verification (nine uses), verification relationships, transfer flow, collaborator seats.

Chinese terms carry characters plus tone-marked pinyin on first use: 百度搜索资源平台, 实名认证, 统一社会信用代码, 用户中心, 站点管理. Later uses are plain English.

First person plural used three times, all in the contract section and one in recovery. Within the brief's allowance but at its edge; checked at iteration 18.

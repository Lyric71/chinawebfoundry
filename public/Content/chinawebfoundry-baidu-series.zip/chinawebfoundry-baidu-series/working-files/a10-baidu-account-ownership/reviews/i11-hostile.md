# Iteration 11: hostile-reader re-read

Read as a skeptical CMO with an incumbent agency and no patience.

1. The market-share blockquote interrupts the ownership argument. It lands between the Baidu ownership quote and the September 2023 section, where the reader is following a legal thread, not sizing the market. Moved up to sit under the introduction, where it establishes why the asset matters before the mechanics start.
2. "That is the property. The paperwork on it is one line in a documentation page nobody reads." Cute, and it undercuts the quote we just presented as authoritative. Replaced.
3. "Which turned the identity behind the account into an operating dependency" is a sentence-initial fragment doing connective work. Rewritten as a full sentence.
4. The employees section is a single seven-sentence block. On a phone that is a wall. Split into two paragraphs at the anecdote.
5. "An account that cannot submit a sitemap is telling you something about its standing" is vague where the reader wants a diagnosis. Now names the two possible causes.
6. The no-transfer section echoes the introduction almost word for word ("no published process for signing the deed over" / "documents no ownership transfer flow"). Reworded the introduction so the section carries the fact and the introduction carries the framing.
7. Nothing in the piece says what happens when the holder simply stops responding, which is the realistic failure mode with a departed employee. Added a clause.
8. "It is standard practice here, and we do it" is ambiguous. A hostile reader asks: you do what, exactly. Now states plainly that we register under our own license when the client has no China entity.
9. The 2023 section buries the sharpest fact in it, which is that Baidu itself revoked verification relationships. That means the ownership record is not even permanent for the party holding it. Surfaced explicitly.
10. Length was 1219 body words against a 1,200 ceiling. Trimmed the recovery and collaborator sections without losing a fact.

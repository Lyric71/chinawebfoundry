# Iteration 13: AI-tell pattern hunt

Patterns found and broken:

1. Rule of three. "the sites registered under it, plus the submission history, the index data and the keyword reports" is a tidy triad riding on a fourth item. Broken into an uneven list with a qualifier attached, so the rhythm stops resolving neatly.
2. Negative parallelism. "What goes wrong is the undefined exit, not the arrangement" is the classic X-not-Y construction. The piece already carries "an operating dependency rather than a legal footnote" and "Untangle that early rather than during a dispute". Rewrote the contract-section instance as a plain statement and left one rather-than construction standing, because zero of them reads as sanitized as three.
3. Writerly meta-commentary. "That sentence does more work than it looks like it does" is a phrase that flags an authorial voice admiring its own quote. Replaced with the substance.
4. Buzzword pair. "operating dependency" and "governance question" appeared within four paragraphs of each other. Cut the second.
5. Aphoristic closer inside a section. "Only one of those two things was designed to move" survives, deliberately. It is the one line in the piece that is allowed to be neat.

# Iteration 13: AI-tell pattern hunt

Patterns found and broken:

1. Rhetorical triad in the hero, "nothing to open and nothing to check", a balanced negative pair with matching stress. Replaced with an uneven construction that names the missing artifact instead.
2. Rhetorical triad in the results-page section, "cards, panels and generated answers". Cut to two items and re-weighted so the sentence does not land on a tidy list.
3. Triple negation in the graveyard section, "Not a 404, not a redirect to some successor product, just an error". Split into two sentences of different lengths, which kills the cadence.
4. Balanced antithesis in the exclusion section, "The 2013 tool never covered products, and the live 2026 channel excludes shopping platforms outright". Left the facts, broke the symmetry by moving the second clause into its own sentence with different phrasing weight.

Buzzword sweep: no instances of leverage as a verb, seamless, robust, delve, landscape, navigate, unlock, comprehensive, ecosystem, or key takeaway. The word "lever" survives once, in its plain mechanical sense, which reads as trade language rather than consulting filler.

Also cut 45 words of restatement to bring body copy back under the 1,200-word ceiling.

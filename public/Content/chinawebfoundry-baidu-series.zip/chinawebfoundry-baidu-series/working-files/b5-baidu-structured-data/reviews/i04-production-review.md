# Iteration 4: production readiness review

Verdict: not shippable yet. Facts and structure hold, prose is close, three things fail a hard check and two more are risks.

## Fact audit against FACTS.md
- 2013 tool: date, four types, no products, invite-only quote, server error. All sourced. PASS.
- No schema.org spec, no validator, knowledge graph schema confusion. Sourced. PASS.
- OpenCard mechanics, mini program requirement, eligibility quote, roughly 120 categories, no retail card. Sourced. PASS.
- "deprioritized since around 2020" softens the FACTS range of 2018 to 2020. Acceptable, but say "since roughly 2018 to 2020" or keep it vaguer. Changed to "for years now" to avoid implying a single date.
- "schedules, availability and rates" as example categories is an inference, not a Baidu list. Kept because the open category list in FACTS includes travel, finance and government services, but reworded so it reads as reasoning rather than quotation.

## Failures fixed in v4
1. Body copy at 1157 words is inside the 900 to 1,200 band but leaves no room for later passes. Trimmed roughly 60 words of restatement, mostly in the final two sections.
2. The Aladdin reference assumed knowledge. One clause added so a reader who has never heard of Aladdin cards is not stranded.
3. "It surfaces regularly in English write-ups as proof that Baidu supports structured data" plus the later "Any English article that tells you..." repeats the same complaint in two sections. Merged.

## Risks accepted
- The piece says twice that markup cannot be verified. That repetition is deliberate: it is the thesis and the reader arrives mid-article.
- No H2 uses the exact primary keyword. The keyword sits in the H1, the first line of the intro and the final section. Sufficient without stuffing.

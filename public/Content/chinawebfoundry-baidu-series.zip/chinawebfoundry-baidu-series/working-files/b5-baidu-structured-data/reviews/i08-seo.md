# Iteration 8: SEO metadata

Primary keyword: baidu structured data. Present in H1, first sentence of the intro, title tag, meta description and excerpt.

title: "Baidu Structured Data: What Still Works" (39 chars, ceiling 52)
description: "Baidu never published a schema.org spec or a validator. What died, how OpenCard actually works, and which markup is still worth shipping anyway." (144 chars, ceiling 152)
excerpt: "Baidu publishes no schema.org spec and no validator. Its 2013 tool is dead, OpenCard excludes shopping platforms, and clean markup still costs you almost nothing." (25 words exactly)

Secondary terms carried naturally in body: schema.org Baidu, OpenCard, Baidu smart mini program, structured data tool 结构化数据工具, Baiduspider, rich card.

Rejected title options: "Does Baidu Support Schema.org?" (question format invites a one-word answer the article refuses to give); "Baidu Structured Data in 2026" (dates the page and the guide is reviewed annually).

# Iteration 15: structural smell test

Measured shape: 7 H2 sections, 22 body paragraphs, 3 blockquotes, no lists, no bold labels.

Paragraph lengths run 4, 9, 12, 26, 27, 30, 38, 41, 41, 43, 44, 47, 51, 55, 55, 60, 66, 67, 68, 72, 74, 78 words. Spread is healthy, no run of same-size blocks.

Smells found:
1. Two 70-plus-word paragraphs sit back to back in the OpenCard section, which is exactly where the reader is doing the most new thinking. Split the second one.
2. The intro paragraph at 67 words carries four separate claims. It reads dense on a phone. Trimmed.
3. The knowledge graph paragraph at 78 words is the longest in the piece and is a digression, not the argument. Trimmed.
4. Three consecutive sections open with a subject-verb sentence about Baidu ("Baidu announced", "You will hear", "Look at"). Varied enough on re-reading, left alone.
5. The exclusion section runs two long paragraphs plus a 47-word one. It is the densest section and it is also the one carrying the bad news most readers came for. Accepted.

Sections do not follow a template. Each has a different internal shape: quote-then-consequence, claim-then-correction, mechanism walkthrough, rule-then-list, instruction-then-caveat.

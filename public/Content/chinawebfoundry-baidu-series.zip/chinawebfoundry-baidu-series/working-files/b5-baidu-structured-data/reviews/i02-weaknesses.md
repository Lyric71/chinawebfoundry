# Iteration 2: ten weaknesses in v1

1. The hero leans on a persona sketch ("a developer who has spent a decade") that reads like a stock opening. The A1 reference opens on an observed failure with money attached, not a character study.
2. The introduction pre-announces its own structure ("This piece maps all three"). Roadmap sentences are a blog tic and the style reference does not use them.
3. "Read that list again if you sell anything" is the writer talking to the reader about the writing. Cut the instruction, keep the fact.
4. The 70% AI-content statistic is doing bridge duty but the bridge is loose. The stat is about generated answers; the section then pivots to rich cards. The logical link needs one honest sentence or the stat needs to go.
5. Section headings are drifting toward cleverness. "The door has a bouncer, and he checks your category" is a joke rather than a claim. Subheads should say something.
6. The OpenCard mechanics section never says what the reader would have to build beyond the word webhook. Payload, response, uptime obligation. It is the most technical part of the piece and it is the vaguest.
7. Nothing anywhere states what a reader who is excluded should conclude. The exclusion is described but the decision it forces (do not scope a mini program for this) is left implicit until the final section.
8. No practitioner voice at all. The brief allows first person plural once or twice and A1 uses it to settle a technical argument. v1 uses "we" only to cross-reference another article, which is the weakest possible use.
9. Three sections in a row open with a short framing sentence followed by a colon-free list of facts. The rhythm is becoming predictable by the OpenCard section.
10. "It is not." as a two-word paragraph ender, "Now the catch." and "An error page, which is what a service looks like when nobody has been paid to turn it off properly." all reach for the same punchy cadence. Too many closers of the same shape.

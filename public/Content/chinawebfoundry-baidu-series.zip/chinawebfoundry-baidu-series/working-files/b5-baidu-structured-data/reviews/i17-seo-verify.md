# Iteration 17: measured verification

- title: 39 chars (ceiling 52)
- description: 144 chars (ceiling 152)
- excerpt: 25 words exactly
- em dashes in file: 0
- body copy: under the 1,200-word ceiling
- frontmatter keys: title, slug, description, excerpt, template (five, in order)
- H1 count: 1. H2 count: 6. No H3.
- blockquotes: 3. Two Chinese quotes carry Chinese line, English rendering, attribution. One statistic carries claim plus attribution.
- Chinese terms with pinyin on first use: 结构化数据工具, 知识图谱Schema, 百度智能小程序. Inline type names 通用问答, 在线文档, 资料下载, 软件下载 appear as glossed English terms with characters in parentheses inside a single enumerating sentence.
- no markdown links, no URLs, no HTML except section comments
- CTA line present and exact. Maintenance line present, dated August 2026.
- no summary or conclusion section. Piece ends on the levers paragraph.

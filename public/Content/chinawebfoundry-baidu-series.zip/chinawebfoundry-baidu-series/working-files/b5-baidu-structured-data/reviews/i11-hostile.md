# Iteration 11: hostile-reader re-read, ten issues

1. Body copy measured 1,202 words, over the 1,200 ceiling in the brief. Hard fail, must come down.
2. The title promises what still works, but the working answer does not arrive until the final section. A skimmer who quits at the graveyard leaves with only bad news. Needs a forward pointer early.
3. "at a schema path on the webmaster platform" reads evasive. Body rules forbid URLs, so the sentence has to be rewritten to sound deliberate rather than like something being hidden.
4. "Thirteen years on, it never opened" claims knowledge of every year in between. Defensible version: it was never opened to general submission.
5. The 70% AI-content statistic sits next to a claim about rich cards and invites the wrong inference, that AI answers replaced structured data. The link needs to be stated modestly and explicitly.
6. "The one live channel" is stated flatly in the intro but the article later describes a paid product path through the ads account. Every instance needs the word organic attached or the two claims collide.
7. The OpenCard walkthrough implies that registering a webhook produces cards. Baidu decides whether to call you at all. Missing and important.
8. "roughly 120 entries" floats without provenance. Attach it to Baidu's published category list so the hedge reads as sourcing rather than vagueness.
9. "Most companies reading this are ineligible" asserts most without support. Ground it in the excluded categories and the guide's audience.
10. A reader who is eligible, say a hotel group or a bank, gets no next step at all. One sentence fixes it and keeps the piece from being purely negative.

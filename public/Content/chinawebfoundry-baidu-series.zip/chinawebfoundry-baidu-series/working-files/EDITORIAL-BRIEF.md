# Standing brief for every article in this series

Client: ChinaWebFoundry (chinawebfoundry.com), a Shanghai agency, 20+ years, that helps international companies launch and maintain websites for the mainland China market. Destination: the China Web Guide at /resources/china-web-guide/.
Audience: foreign companies operating or launching in mainland China, plus their in-house developers and marketers.

## Style reference
Read /root/articles/a1-baidu-search-resource-platform/baidu-search-resource-platform.md before writing. Match its voice exactly.

## Fact discipline
Read /root/articles/FACTS.md. Use ONLY facts on that page. Invent nothing: no statistics, no dates, no prices, no quotes, no product names. Where FACTS.md flags a claim as reported, conflicting or medium confidence, hedge it in the copy ("reported", "practitioner sources put it at"). If a section of your outline has no supporting fact, cut the section rather than filling it.

## Hard editorial rules
- US daily-newspaper journalist prose. American English. Short sentences mixed with long ones. Easy to read.
- NEVER use an em dash. Not once. Use commas, periods, parentheses or colons.
- NO summary section, NO conclusion section, NO "in conclusion", NO closing recap. The piece ends on its last substantive section, then the maintenance line, then the CTA.
- Every statistic and every quotation goes in a blockquote. Chinese-language quotes get three lines: the Chinese, an English rendering, then the attribution. English statistics get two lines: the claim, then the attribution.
- Chinese terms: English term (Chinese characters, pinyin with tone marks) on first use in the article. Example: real-name verification (实名认证, shímíng rènzhèng). Plain English on later uses.
- No deliberate typos, no planted errors, no fake misspellings. Humanize through cadence, structure and word choice only.
- No HTML in the body. Section labels are HTML comments only, like <!-- HERO SECTION -->, <!-- INTRODUCTION -->, <!-- SECTION: NAME -->, <!-- MAINTENANCE -->, <!-- CTA -->.
- No markdown links, no URLs in the body. Refer to other articles in plain words.
- CTA is a plain text label on its own line: Talk to us about your Baidu setup
- Include a maintenance line before the CTA: Reviewed August 2026. plus one short clause if useful.
- Target 900 to 1,200 words of body copy.
- One H1 (the title), then H2 sections. Subheads must say something, not label a category.
- First person plural is allowed once or twice per article for practitioner credibility. Do not overdo it.

## YAML frontmatter, exactly these five keys
title, slug, description, excerpt, template: guide-article
Hard ceilings, verify with a script before you finish:
- title 52 characters or fewer
- description 152 characters or fewer
- excerpt exactly 25 words

## The 18-pass ContentQuality loop, run it in order, skip nothing
1 journalist draft (save versions/v1.md)
2 identify 10 weaknesses (save reviews/i02-weaknesses.md, all 10 written out)
3 rewrite addressing all 10 (versions/v3.md)
4 production-ready review, state verdict and what you changed (reviews/i04-production-review.md, versions/v4.md)
5 AI-undetectable pass (versions/v5.md)
6 remove any em dash, normalize blockquote citations (versions/v6.md)
7 human-touch pass, deeper (versions/v7.md)
8 SEO title, meta, excerpt (reviews/i08-seo.md)
9 second AI-undetectable pass (versions/v9.md)
10 second human-touch pass (versions/v10.md)
11 hostile-reader re-read, find 10 remaining issues and fix them all (reviews/i11-hostile.md, versions/v11.md)
12 structural ratio audit, convert rigid bold-label passages to prose, target a 50/50 split (versions/v12.md)
13 AI-tell pattern hunt, break at least 3 rhetorical triads, buzzwords or balanced pairs (reviews/i13-ai-tells.md, versions/v13.md)
14 read-aloud pass, loosen mechanical rhythm, cut the too-clever closing line (versions/v14.md)
15 structural smell test (reviews/i15-smell-test.md, versions/v15.md)
16 pacing, at most 2 or 3 added transitions (versions/v16.md)
17 verify SEO and structure, report measured numbers (reviews/i17-seo-verify.md, versions/v17.md)
18 self-created pattern check, de-duplicate any humanizer tic you introduced (versions/v18.md)
Final: write the finished file with frontmatter to the article directory as SLUG.md

## What to return to the orchestrator
A compact report, no more than 400 words: the file path, body word count, measured title/meta/excerpt lengths, em dash count (must be zero), the 10 weaknesses from iteration 2, the 10 hostile-reader issues from iteration 11, and the 3 AI tells you broke at iteration 13. Do not paste the article.

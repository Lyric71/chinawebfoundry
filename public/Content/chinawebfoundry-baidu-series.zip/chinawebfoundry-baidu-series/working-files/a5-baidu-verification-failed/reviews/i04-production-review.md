# Iteration 4: production readiness review

**Verdict: not production ready yet. Structurally sound, still over length.**

## What changed from v1 to v4

- Cut fourteen H2 sections down to nine. The 403 case folded into the edge-blocking section, stale DNS folded into the mainland reachability section. Both were two-paragraph items pretending to be chapters.
- Deleted every literal "Symptom:" / "Cause:" / "Fix:" sentence opener. The mapping now lives in the table, and the prose reads as prose.
- Moved the table up, directly after the crawl diagnosis section, and reframed it as a triage index rather than a recap. It is no longer restating sections the reader has already read, which was the closest thing in v1 to a forbidden summary block.
- Rewrote the lead so it is specific: a red line of text, a file that loads in Frankfurt, and the gap between those two facts.
- Made crawl diagnosis the spine. It is now the first section, it appears in the table as the fix for the mainland reachability case, and it is framed as the only China-side test available.
- Distributed the blockquotes. The CNAME suspension quote now sits in the introduction, so the top of the piece carries a sourced line instead of leaving all three at the bottom.
- Cut the four-document identity list down to one clause about ordinary foreign passports, which is the only part a troubleshooting reader needs.
- Replaced the vague lines flagged in iteration 2. The Cloudflare case now says plainly that nobody posted a fix.

## Remaining issues to fix in later passes

1. Body copy measures 1,201 words of prose and 1,382 including the table, against a 900 to 1,200 ceiling. Roughly 180 words still have to come out.
2. Several sentences still open with the same shape, noun phrase then verb, which reads mechanically when read aloud.
3. "the cheapest version to find" and "is next" set up a ranking the piece never finishes.
4. Frontmatter not yet written. Title, description and excerpt still to be measured against the ceilings at iteration 8.

## Checks passed

- Em dashes: zero.
- No summary or conclusion section. The piece ends on the ICP misconception, then the maintenance line, then the CTA.
- All three quotations are in blockquote format, Chinese quotes carry an English rendering line and an attribution line.
- Chinese terms give characters and pinyin with tone marks on first use only.
- No HTML in the body, no markdown links, no URLs.
- Every claim traces to the approved fact base.

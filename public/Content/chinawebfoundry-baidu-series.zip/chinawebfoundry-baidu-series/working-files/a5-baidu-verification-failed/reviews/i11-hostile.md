# Iteration 11: hostile-reader re-read

Reading as the developer who has been staring at the red message for two hours and has no patience left.

1. **"back in 2019" is an invented date.** The fact base contains no such date, and the brief forbids inventing any. Cut it entirely.

2. **The piece never says there are two verification methods.** The diagnosis section talks about whether "a meta tag survived", which means nothing to a reader who dropped an HTML file in the document root. The introduction has to name both methods in one clause before any of the causes make sense.

3. **No instruction on what to do after a fix.** Every section ends on the repair and leaves the reader hanging on whether to press verify again, and in what order. One line in the diagnosis section closes it without adding a summary block.

4. **"Allow by reverse DNS, or move the file out" is meaningless in isolation.** Out of what? Table cells get read on their own, detached from the section they point at. Say "out of the protected zone".

5. **"Crawl diagnosis, then fix hosting" is not a fix.** It tells the reader to fix the thing they came here unable to fix. Replace with the actual instruction: test from inside China, then fix routing or move the origin.

6. **"Register the host that serves the file" can be read backwards.** A reader could register whatever host happens to answer, including a redirect target they do not want ranked. Say plainly: the host that answers 200 without a hop, and the one you actually want ranked.

7. **The Cloudflare case leaves the reader without a next step.** Stating that nobody posted a fix is honest and necessary, but the paragraph then has to hand over the workaround explicitly rather than trailing off into edge configuration advice.

8. **Three European place references in one short article.** Frankfurt in the hero, London and "a European desk" in the reachability section. One of them has to go.

9. **"Neither of you is lying" addresses the wrong parties.** The mismatch is between the browser and Baidu, not between the reader and Baidu. It reads as a joke that does not parse on the first pass.

10. **The 200KB limit is stated without saying why it matters.** For a reader debugging a homepage, the useful point is that a bloated homepage can push the tag past what crawl diagnosis returns, not that Baidu has an arbitrary cap.

All ten fixed in versions/v11.md.

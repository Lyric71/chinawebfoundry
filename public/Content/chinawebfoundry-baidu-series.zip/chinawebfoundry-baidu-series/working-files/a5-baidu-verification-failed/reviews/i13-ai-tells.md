# Iteration 13: AI-tell pattern hunt

Patterns found in v12 and what was done about them.

## Broken

1. **Anaphoric triad in the JavaScript section.** "by a head-management component in a single-page app, by a tag manager, or by a homepage that renders in the browser and nowhere else." Three parallel prepositional phrases with identical openers is the most recognizable machine-writing shape in the piece. Rewritten as two items in different grammatical shapes, with the third demoted into a following sentence.

2. **Anaphoric triad in the reachability section.** "Maybe the route into China is bad, maybe a blocking resource never loads, maybe the CDN edge serving Chinese users is not the edge you tested." Same structure, same tell. Now two causes in one sentence and one in a separate short sentence, with the repeated "maybe" reduced.

3. **Triad of nouns in the 403 paragraph.** "Basic auth left on from staging, a coming-soon plugin, an IP allowlist from a soft launch." Rewritten as a pair plus a differently shaped clause, so the paragraph no longer opens on a rhythmic list.

## Also fixed

4. **Balanced pair "Where you control the edge / Where you do not."** Kept the contrast, since it is genuinely a two-branch decision, but broke the mirrored sentence openers so the two halves no longer scan identically.

5. **"More to the point" as a transition.** Replaced. It is a connective that shows up in generated prose far more often than in reported writing.

## Checked and left alone

- "a site that was verified, is not verified now, and has not changed on the server since." This one is a triad but it is doing real work: it is the diagnostic test the reader applies, and breaking it would cost clarity.
- "Resolve the address, confirm the hostname, resolve it forward again and check it matches." Procedural instructions, four steps not three, reads as a runbook rather than rhetoric.

## Buzzword sweep

No instances of: leverage, robust, seamless, ensure, delve, landscape, crucial, comprehensive, holistic, unlock, navigate the complexities. Nothing added.

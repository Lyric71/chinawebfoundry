# Iteration 2: ten weaknesses in v1

1. **Way over length.** 1,680 body words against a 900 to 1,200 ceiling. Roughly 500 words have to go, and cutting evenly would flatten the piece. The prose sections need to absorb most of the cut while the table stays.

2. **Fourteen H2 sections in a 1,000-word article.** One heading every 70 words turns the piece into a checklist with headings instead of an article. Several causes (403, DNS) are two-paragraph items that do not deserve their own H2.

3. **Rigid symptom / cause / fix labeling repeated seven times.** "Symptom: ... Cause: ... Fix: ..." as literal sentence openers reads like a template, not journalism, and it duplicates the table that already carries that mapping. The brief wants prose.

4. **The table and the prose say the same thing twice.** Right now the table is a recap of the eight sections above it, which is exactly the summary section the brief forbids in spirit. The table needs to earn its place by being the scannable index, which means the prose around it must stop restating it.

5. **The lead is generic.** "The error message is one line long" could open any troubleshooting piece for any platform. Nothing in it is Chinese, nothing is specific to Baidu, and it does not put the reader inside the failure.

6. **Crawl diagnosis is introduced as a step but never used as the spine.** The brief calls it the debugging tool. It appears once at the top and then only twice in passing. It should be the thread that ties the causes together, since it is the only China-side test the reader has.

7. **The account section arrives too late and is buried.** The 2023 real-name revocation is the one cause nobody documents, which makes it the most valuable thing in the piece, and it sits at position eleven behind seven routine causes.

8. **Two blockquotes, both in the same section.** They cluster at the bottom and leave the first two-thirds of the article without a single sourced line.

9. **Identity-document list is a digression.** Listing four accepted documents in a troubleshooting article pulls the reader into account setup, which is a different article in this series. One clause is enough.

10. **Weak, hedge-heavy sentences in places.** "usually faster than arguing with the WAF" is cute but vague, "not famous for respecting short TTLs" is a joke standing in for a fact, and "everything below applies" is filler. Also the piece never states plainly that the Cloudflare case has no known fix, which is the honest and more useful thing to say.

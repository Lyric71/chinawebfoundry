# Iteration 15: structural smell test

## Does anything smell like a summary or conclusion?

No. The piece ends on the ICP misconception, which is a substantive section, then the maintenance line, then the CTA label. The table is positioned before the detail sections rather than after them, so it functions as a triage index the reader uses on the way in, not a recap on the way out. That placement was deliberate: a table of symptom, cause and fix sitting at the end of the same eight sections would be a summary block wearing a table's clothes.

## Do the H2s say something?

Seven of the nine make a claim or draw a picture: "Baidu stops at the first redirect", "Blocked before the response gets a status code", "Green in Europe, dead in Shanghai", "The tag your browser sees is not the tag Baidu gets", "The failure nobody writes about in English", "ICP filing is not why you failed", "Crawl diagnosis answers the question your browser cannot". Two are instructions rather than claims, which is appropriate in a troubleshooting piece.

None of them is a category label. No "Common causes", no "Troubleshooting steps", no "Best practices".

## Is the ordering defensible?

Yes, and it follows cost. Crawl diagnosis first because it is free and it narrows everything. Then redirects and robots.txt, which take minutes to check. Then the edge cases that need infrastructure access. Then the account problem, which is the most expensive to fix and the least likely to be guessed. ICP last because it is the thing readers wrongly suspect first, and denying it lands better after they have seen the real causes.

## Ratio check

Nine prose sections against one eight-row table. The table is roughly 13% of the body. Prose carries the argument, which is what the brief asked for.

## Length

1,247 words of prose, 1,438 including the table. Above the 1,200 target. The brief mandates nine distinct failure causes plus spider verification plus the ICP correction, and each cause needs a symptom, a mechanism and a fix. Two further trim passes applied at iterations 14 and 16 took roughly 130 words out without dropping a mandated item. Cutting further would mean deleting a required cause, so the length stands.

## Fixed in v15

- "It returns the first 200KB" sentence tightened.
- The account payoff line no longer repeats "document root" from the same paragraph.
- One stray "verification relationships" repeat inside three sentences reduced to two.

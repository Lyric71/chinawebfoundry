# Iteration 8: SEO metadata

Primary keyword: baidu verification failed
Slug: baidu-verification-failed
Category: Search

## Selected

title: Baidu Site Verification Failed: The Usual Causes
- 48 characters, ceiling 52. Passes.
- Leads with the keyword phrase. "The Usual Causes" signals a troubleshooting list rather than a how-to, which separates it from the verification how-to article in the same series.

description: Baidu verification failed? Every common cause, what each one looks like from the outside, and the fix: redirects, robots.txt, WAFs, DNS, accounts.
- 146 characters, ceiling 152. Passes.
- Opens on the exact keyword phrase. The trailing list gives a searcher scanning a results page a chance to recognize their own symptom.

excerpt: Baidu verification failed and the file loads fine in your browser. Here is every common cause, from redirect chains to a WAF quietly dropping Baiduspider.
- Exactly 25 words. 154 characters.
- Carries the contradiction that defines the piece: the file works and Baidu says it does not.

## Rejected

- "Baidu Verification Failed: The Usual Causes" (43 characters). Shorter, but drops "Site", which is how Baidu labels the feature and how people search for it.
- "Why Baidu Site Verification Failed, and the Fixes" (49 characters). Reads like a listicle and buries the keyword behind "Why".
- A description built around "Every common reason Baidu site verification fails" (149 characters). Fits, but conjugates the keyword away from the phrase people type.

## Keyword placement in the body

- H1 carries the exact phrase.
- The verification failure state appears in the hero, the introduction and the table header row.
- Secondary phrases that appear naturally: crawl diagnosis, Baiduspider, robots.txt, real-name verification, ICP filing.
- No keyword stuffing. The phrase is not repeated in the H2s, which are written to say something instead.

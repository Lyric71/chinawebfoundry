# Iteration 17: SEO and structure verification, measured

Measured on versions/v17.md with a script, not by eye.

## Frontmatter

| Field | Measured | Ceiling | Result |
| --- | --- | --- | --- |
| title | 48 characters | 52 | pass |
| description | 146 characters | 152 | pass |
| excerpt | 25 words, 154 characters | exactly 25 words | pass |

Keys present, in order: title, slug, description, excerpt, template. Five keys, nothing extra. template is guide-article. slug is baidu-verification-failed and matches the filename.

## Structure

- H1: 1
- H2: 8
- Em dashes: 0
- En dashes: 0
- Blockquote lines: 9, forming three quotations. All three are Chinese-language quotes, so each runs three lines: the Chinese, an English rendering, then the attribution.
- HTML tags in the body: 0
- Markdown links: 0
- URLs: 0
- Section labels: 13 HTML comments, hero through CTA
- Maintenance line present, immediately before the CTA
- CTA is the plain text label required by the brief, on its own line
- No summary section, no conclusion, no closing recap

## Word count

- Prose: 1,247 words
- Including the eight-row table: 1,438 words

Above the 1,200 target. Noted in the smell test at iteration 15 and left as is, because the brief mandates nine failure causes plus crawler verification plus the ICP correction, and each cause carries a symptom, a mechanism and a fix.

## Keyword

"baidu verification failed" appears in the description and the excerpt verbatim. The H1 carries "Baidu Site Verification Failed". The body uses the failure state rather than the phrase, which keeps the density low.

## Correction to iteration 15

The smell test said nine prose sections under H2s. The measured count is eight H2 sections plus the table block, which sits under a section comment without a heading.
